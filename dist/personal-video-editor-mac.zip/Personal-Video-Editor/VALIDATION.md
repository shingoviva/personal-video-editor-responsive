## 2.2.85 公開前候補（2026-10-24）

全JS96/build、38検証command（Python/FFmpeg/HTTP29suite含む）成功。C/W実UI・400FX・群複製・形式2旧版拒否、30s全900frames/PTS誤差0.334µs/36marker lag0sample、全経路PCM一致。WebKit映像は再出力ばらつきあり、完全一致とはしない。Mac ZIP標準展開JS/HTTP成功。詳細は `docs/PVE-2.2.85-RELEASE-REPORT.md`。最終承認前・remote未公開、実iPhoneはユーザー確認。

## Phase 2b 未公開候補（2026-10-24）

全JS96 entrypoint・build・Python/FFmpeg/HTTP29 suite成功。30秒720p/200 flash+TEXT/音楽のChrome・macOS WebKit・Mac出力は全900frame、36マーカー位置差0sample。前後の全デコード映像/PCM一致。詳細・性能の遅い側・実機未確認は `docs/PVE-PHASE-2B-RELEASE-READINESS.md` を参照。アプリversion2.2.84、次版2.2.85は提案のみ。公開なし。

## 2.2.84 安定化候補（公開承認待ち）

- 隔離release/pve-2.2.84で全93JS/build、Python/FFmpeg/HTTP29本PASS。研究用free fixture testを配布から外し、正式muxの構造／失敗・取消・再試行を維持。
- 新規Chrome47＋WebKit47、独立282比較／1314markerでlag/drift0sample。既知AAC品質FAILは元基準のまま記録し、新規悪化なし。
- B1〜B4実操作・保存復元・OPFS、Mac等速44／B4時計32・10bit、実写transition24比較PASS（dissolve+.2s MAE 3.138）。
- package/lock/UI/engine/cacheを84統一、200JS/Worker参照を検査。依存MediaBunny1.56.0維持、patch再適用／未知版停止を確認。
- 元のtext02/Labと未公開差分を保持。ユーザーがMac/Chrome/iPhone-Safariを実機受入済みと申告。物理2msのagent測定ではない。
- 詳細 [リリース報告](docs/PVE-2.2.84-RELEASE-REPORT.md)。push/tag/公開は承認まで未実施。

## 2.2.83 音量ライン・タイムライン縮小（2026-10-22）

- 公開候補は2.2.82から音量ラインUIと時間軸縮小のみを選別。静的文字最適化02、Feature Lab、開発環境整理は除外。音声DSP・保存schema・書き出し処理は変更なし。
- npm test全89スクリプト/build PASS。音量188,584計算の既存一致試験、境界点確定前後1601点完全一致、表示のみでは保存/履歴を変えないこと、hold/上限256/タッチ二重発火抑止を確認。
- Chrome Mac/Chromeスマホ寸法（native CDP touch）/WebKitスマホ寸法（mouse drag+native touch doubletap）：動画原音/音声の水平±gain、始終端固定、フェード、中間点、Undo/Redo、横drag移譲、上部trimとの分離、英語案内を確認、pageerrorなし。
- Chrome Mac/スマホ寸法：1%でもレーン幅を維持、10%で素材幅1/10、遠い配置（Mac90秒・スマホ約43.87秒、既存吸着あり）、Undo/Redo、再読込で時刻保持。スマホnative2点touchの100→25%を確認。表示上限24時間の単体検証追加。
- Chromeで通常プレビュー、再生中seek/ヘッドdrag継続、Shift loop、素材右クリック/配置先を確認。WebKitはパネル遷移待ちを補った同手順でV3/A4配置を確認。
- 4音声レーン付き保存→reset→restore、Undo/Redo、再生/seek/停止再開、端末内1080p30 H264/AAC実worker出力と全decode PASS。通常URLの診断UI/observer/GPUtimer/worker hook起動なし。
- Python実動画/音声/HTTP22試験PASS。初回のNode共有ライブラリ起動失敗は正常なNode24 PATHで失敗箇所以降を再検証。バージョン固定UI試験を83へ更新。
- 実機iPhone/Safari本体、スピーカーでの聴音、長時間連続編集は今回未確認。WebKit自動試験を実機認証と扱わない。

## 2.2.82 再生とライブラリ（2026-10-22）

- npm test 89スクリプト/build、Python実動画・音声・HTTP22本PASS。seekの最新世代/停止取消/古い成功・失敗/停止中seek/FXの明示再生とダイアログ復帰の回帰試験を追加。音量188,584計算は引き続き旧式と一致。
- Chrome実操作：再生中ルーラーseek・ヘッドdragで自動resume、末尾seekは巻き戻さず停止、Shift-click/Shift-SpaceでEOFからloop、停止で解除、Shift単独再生停止維持。32pxのMac playとfocus ringはviewer内に収まる。
- 素材の詳細動画を再生して別タブへ移ったとき、旧HTMLMediaElementを停止しsrc解放する回帰確認を追加。
- 動画/静止画V1–V3、音声A1–A4のカード指定と実配置、右クリック/Shift-F10、rename、詳細動画preview、使用中素材remove無効を確認。WebKitスマホ寸法で同じレイヤー指定/配置を確認。
- Chromeで4音声レーン付き保存→reset→restore→再生/seek/停止再開→端末内1080p30 H264/AAC実worker書き出し・全decode成功。通常URLの診断UI/observer/GPUtimer/worker hookは起動なし。
- 実機iPhone/Safari、スピーカーでの連続loop/seek聴音は未実施。Playwright WebKitの外部font load待ちを試験の初期化条件から外し、UI初期化で再試験。公開とMac ZIPはclean candidateから生成しLabを除外。

## 2.2.81 音量automation最適化・開発者診断（2026-10-22）

- Feature Labを除いた公開候補からnpm test（88スクリプト）・npm run buildを実行しPASS。旧式との188,584計算、Float32予約・時刻が完全一致。
- Chrome/Playwright WebKit：7レーン×ステレオ、各1,008,000レーン別PCMと固定順合算が誤差0。Chrome native mixerの別context間では旧/旧でも最大2.98e-8の丸め差あり。詳細は最適化01レポート。
- Python実動画・音声処理試験22本PASS。H.264/AAC・ProRes・フェード・トランジション・重ね合成・字幕・FX・速度・複数音声・実HTTP配信を含む。localhost試験はsandbox loopback制限による失敗後、必要権限で再実行してPASS。
- 隔離Chrome通常URL：音声4レーン付き.project保存→リセット→再読み込み→プレビュー→シーク・停止・再開、Undo/Redo成功。端末内WebCodecs/workerで1080p30、36フレームの実H.264/AAC書き出し・全フレームdecode成功。
- 音量モジュールの依存URLも2.2.81へ統一し、旧unversioned mobile-modelが残る状況を再現して起動/再生/保存復元/端末書き出しを確認。依存URLの版番号一致を回帰試験へ追加。
- 通常URLで診断panel/global/controller/activeなし、PerformanceObserver生成0、GPU timer extension要求0、Worker/getContextフックなし、診断UI module未読込。診断URLの複合F再生・JSON/Markdown出力・clear成功。JSON schema12レポート・比較CLIの利用を維持。
- Mac ZIPを公開対象だけから生成し、2.2.81・schema同梱・Feature Lab非混入を確認。展開したZIPで新音量試験・診断試験PASS。
- 実機iPhone/Safari本体、実スピーカー聴音・出力遅延、長時間編集、Mac Launch.commandのGUI操作は未検証。Playwright WebKitの素材永続化は既知の一時環境制限のためメモリー内素材経路だけを確認。
- 映像レンダラー・書き出し設定・保存schema・音声同期/gateに仕様変更なし。限定条件の性能結果を一般環境の保証値としていません。

## 2.2.80 書き出し名の検証（2026-10-22）

- ファイル名欄は現在のプロジェクト名を初期入力し、その書き出しだけ任意の名前へ変更できます。
- 日本語・英語・空欄・拡張子付き・危険文字・長い名前・NFCのMac／ブラウザ処理一致を確認。
- Mac配信のinlineプレビュー／attachment保存、日本語RFC5987保存名、MP4／MOV、Range部分取得、ヘッダー注入防止を実HTTP試験で確認。ファイルの内部IDや映像・音声処理は維持。
- 実画面で日本語プロジェクト名が設定欄と保存予定名に入ることを確認。実機iPhone／Safari本体は未検証。

## 2.2.78 — FX不整合の修正

実タイムラインの移動と実checkpoint/saveで、解析済みFXの時刻・長さ・枠の変更後は旧解析を破棄し、強さ・レイヤー・戻り・文字追従のみの変更とUndoでは有効な解析を保持することを確認。旧projectは変更前のrender/checkpointでFX stampを補い、保存の入口でも検証。再生中の解析は追加していません。

40秒のBLACK→IMAGE／IMAGE→BLACK／FLASHとバッチ合成を実書き出しし、35秒で指定どおりの画素と全尺decodeを確認。基準出力と音声PCM完全一致。色FXのF/T3/F/T1配置を維持して追加順だけ反転した2出力は同じ画素、PCMも完全一致。実paintPreviewの色FX順序、非表示、合成ズーム順も検証。既存の合成段階（色→FOCUS→全体ズーム）とテロップ追従仕様は維持。設計 docs/effect-compositing.md。

実機iPhone／Safariの今回の変更は未確認。公開前の全検証を別途実施します。

## 2.2.77 — 再生時計・デコーダー所有権・描画周期の整理（公開前検証済み）

表示中の動画を時計として切り替える構造を廃止し、再生開始時に音声デバイス時計（利用できない場合は単調増加時計）を固定。微小なずれは無音映像の最大±4%速度補正、明示シーク・新クリップ・大きい差は正確なフレーム待機を使用。音声デバイス中断では停止します。

待機デコーダーを先読み専用クラスで管理。現在のクリップへの引き渡し前に未来のクリップを先読みして、準備済みフレームを上書きする競合を修正。クリップ切替は旧リクエストを中止して即座に処理し、遅れた完了や失敗を無効化。下レイヤーはフェード等で必要になる直前に予熱し、不要時は解放。描画周期は表示リフレッシュとの差分を保持し、未準備フレームの待機で描画枠を消費しません。設計・保守上の不変条件は docs/preview-playback.md。

低負荷の実ブラウザ計測：6秒・3レイヤーフェードで154→181描画、最大描画間隔117→42.5ms、下位準備待ち4→0、連続再同期シーク0。全境界で準備済みフレームを採用。繰り返しスクリーンショットで観測した約250ms停滞は、この低負荷計測では再現していません。

30秒・音声付き動画／5クリップ／3レイヤーの実再生も終端へ到達。有限リング記録の残存区間3.35〜30秒で799描画、最大間隔42.3ms、連続シーク0、音声時計との差最大2.7ms、残存する7回の切替すべてprepared。393×852幅でも30秒完走、残存区間の最大描画間隔53.9ms、音声時計差最大2.7ms。停止→再開、終端→1フレーム戻す→再生も終端へ正常到達。これは診断上の時計一致であり、聴覚評価を意味しません。実機Safari／iPhoneとユーザー実プロジェクトの長時間再生は未確認。

npm test全84／build成功。native layers・transitions・creative・multitrack・clip-boundaryの映像と音声の実出力試験成功。既存audio/exportロジックは変更せず、待機・中断・後着・連続シーク・リソース解放の回帰試験を追加。2.2.77公開対象の検証記録です。

### 追加監査：再生以外の状態遷移（2026-10-20）

読み込み中断後の復帰という別観点で、Bのstandby読み込みを中止してAへ戻ると、共有loadPromiseに残ったAbortErrorで正常なAまで再生準備失敗になる経路を実syncVideo試験で再現。読み込みPromiseをリクエスト内へ局所化し、古い共有状態と不要な再待機を撤去。実際の中止→元decoder保持→seek/replay復帰を確認。遅い読み込みを伴うこの分岐はVM回帰試験であり、実機の低速ネットワーク試験ではありません。

空白区間／素材内IN点／0.2・0.5・1・5倍速／freeze／同一layer重なり／全5種transitionの20組合せで下位準備と実合成条件の一致を追加確認。映像なしの計画も確認。設定変更はmutateで停止し、planを破棄する既存経路を点検。npm全84、変更試験個別、build、diffcheck成功。音声・書き出しロジックは変更していません。

### FX・テキスト追加監査（2026-10-20）

実paintPreviewを使う回帰試験で、main/lowerフレーム待機中にpaintRegionZoomだけが先行し、前の映像とテロップに新時刻の変形がかかる経路を再現。再生中の幾何変形を合成確定の段階へ移し、映像・ズーム・テロップの変形を同時に反映。停止中の範囲編集は即時反映を維持。

実FX/テキスト描画経路で開始直前／開始／途中／終了、映像なし、テロップ追従ON/OFF、overlay各段非表示、削除、データ復帰後の再表示を追加検証。既存の文字装飾・文字アニメーション・解析FX・キャンセル・削除後リソース解放の試験も含めnpm全84、build、diffcheck成功。ネイティブregion-zoom・overlay-only・material-fxの実出力試験も成功（文字追従ON/OFF、画素・音声・全尺decode）。ローカルFFmpegでdrawtext非対応のため文字はraster経路で検証。実機Safari/iPhoneの今回の変更は未確認。公開はしていません。

### 未確認分岐の追加監査（2026-10-20）

静止画切替には動画と同等の準備待ちがなく、旧映像・旧bitmapへ新しいFXやフェードを適用し得る分岐を実paintPreview試験で再現。現在URLと一致するbitmapができるまで直前の構成を維持するよう修正。さらに壊れた静止画で再生時計だけ進む経路を実syncVideoで再現し、現在の画像読み込み失敗は停止するよう修正。期限切れの画像エラーは別クリップを止めず、古い通知も出しません。

修正前FAIL→修正後PASS。画像キー不一致／bitmap未生成／現画像decode失敗／遅着した旧画像decode失敗を追加検証。設定変更の入口も点検し、速度・IN/OUT・配置・layer・文字時間・overlayドラッグは停止と計画破棄を通ることを確認。既存freeze/速度/transition試験とともにnpm全84、build、diffcheck成功。native imagesでPNG+動画+WAV BGMの動き・音声・全decode・原素材保持成功。実機Safari/iPhoneの混在切替と破損画像は未検証。未公開。

## 2.2.76 — 3レイヤーフェードのプレイヤー切替

同じ6秒動画をV1/V2/V3へ、素材内時刻と配置時刻が一致するよう配置し、上位2段にfadeIn .75秒／fadeOut .6秒を設定。修正前は3段目開始時に古い画面が暗く現れるフレームを実ブラウザで記録。シーク後のフレーム提示待ち、下レイヤーの準備と不透明度の同時反映、同素材の期限切れクリップの非同期復帰拒否を追加。修正後はMac幅109記録／393px幅102記録で切替区間の棒位置の逆戻りと黒画面なし（映像終了後の黒画面を除外）。音声・書き出し処理は非変更。

新規試験でseeked先行／古いフレーム／フレーム時刻丸め／キャンセル／timeout／error／旧API fallback／削除／同一素材の非同期切替を確認。実paintPreview関数の試験で準備前の合成と不透明度の保持を確認。npm test全76／build／diffcheck PASS。実機Safari／iPhoneは未検証。未接続の下レイヤーとデコーダー失敗時に合成を無期限に止めない回帰試験も通過。

## 2.2.75 — 透過プレビューと切り替え演出の背景合成

未使用の切り替え用描画面を非表示に保ち、不透明度とフェードで下の映像を表示。演出中も前クリップの不透明度を維持し、下レイヤーを誤って省略しないよう修正。実プレビュー関数を使う回帰試験を追加。映像・音声の書き出しロジックは変更なし。実機Safari／iPhoneは未検証です。

## 2.2.74 — 編集ハンドルのホバー位置を固定

共通ボタンのホバー時transformがハンドルの中心補正を上書きしていた問題を修正。四隅のhover／active／keyboard focus中も位置を維持。実ブラウザで四隅ともhover前後0px、SE拡縮時の対角固定とUndo復帰、console errorなしを確認。映像・音声の処理は非変更。実機Safari／iPhoneは未検証です。

## 2.2.73 — 出力画面の目安と精細な編集ハンドル

本来の出力画面に薄い1px枠を表示。四隅の見た目は8pxに抑え、操作範囲はMac24px／iPhone32pxを確保。中心座標・吸着・映像と音声の処理は維持。枠とハンドルは編集画面だけに表示し、書き出しに含みません。実画面・実機Safariの今回の見た目は未検証です。

## 2.2.72 — プレビュー直接操作・Option複製・等間隔

四隅は素材の実際の表示境界に一致し、対角固定・縦横比維持で拡縮。移動は100%でもカーソルに追従し、Optionで中心拡縮。Optionの途中押し複製、前後へ並べ足す等間隔案内・吸着、音声リンクIDとUndo表示を修正。画面外の角を内側へ寄せる補正は行いません。実機iPhone／Safariの操作感は未検証です。

## 2.2.71 — 片辺吸着とFACE FOLLOW

片側の辺だけが画面枠に接した場合も吸着。FACE FOLLOWはFX開始画面の枠に近い顔を端末内で解析し、保存した軌跡で追従ズームします。解析は明示操作・最長30秒・1動画クリップ内に限定し、通常操作で中止。再生・書き出し中に顔認識しません。見失った箇所は直前の位置を保持。

## 2.2.70 — プレビューサイズの画面枠吸着

サイズ変更中、上下左右の画面枠に8px以内で吸着し、揃った辺にガイドを表示します。縦横比の異なる素材の左右／上下fit、ドラッグ続行での解除、Ctrl／Metaホイールにも対応。音声・書き出し処理は維持。実機Safariの操作感は未確認です。

## 2.2.69 — LOOKの操作負荷・一括再リンク案内

LOOK一覧サンプルの小分け生成・同一フレーム再利用・タブ切替時の中止を導入。実プレビューと書き出し画質は維持。一括再リンクの未接続クリップ数／素材数とフォルダ選択案内を追加。実機Safariでの体感改善は未確認です。

## 2.2.68 — 一括再リンク／クリップ素材差し替え（2026-10-17）

- 属性ペーストの速度変更時、リンク音声の速度・尺を同期し、保持する音量ポイントの時刻を再投影。専用回帰試験で素材・IN/OUT・配置の保持と深いコピーを確認。

- npm test（追加のmedia-replacement試験を含む）／build／diffcheck成功。200素材の上限状態でも既存の実importFilesをVMで動かし、複数targetの接続・単一checkpoint・クリップ追加なしを確認。
- 階層付きフォルダ照合、同名同容量の重複保留、容量差拒否、保存済み相対位置による重複解消を試験。素材差し替えの速度／時間範囲／フェード／音量エンベロープ保持、選択した1クリップだけの更新、短い素材・異種拒否、リンク音声の追従／独立化、source依存FXの対象限定無効化も確認。
- 隔離Chromium UIで、親フォルダ配下Audio/sub・Stillsの2素材一致／同名2ファイルの1素材保留を確認し、明示確認後に2素材接続。音声差し替え用の新規ファイル読み込み→確認→選択1クリップ更新、Undo／Redo、再生進行・終端停止、再起動後の接続維持を確認。
- UI保存.projectを元データと正規化後に比較。対象のmedia IDだけが異なり、その他の全クリップデータは一致。MIX設定のフェード0.40／0.80も表示確認。
- 差し替え後に端末内H264/AAC MP4を実生成（640x360/30fps/8秒、240フレーム）。Macエンジン実機接続と実機iPhone/Safariでのフォルダ選択・実音確認は未実施。
- 追加の動画／静止画検証: 位置／拡大／color／keyframe／transition／fadeを含む全設定と兄弟clipの保持を試験。隔離UI8799でCOLORから動画、MOTIONから静止画を同じ確認操作で変更。実UI保存.projectは2クリップともmedia ID以外が正規化後完全一致。静止画Undo／Redo確認、H264/AAC 320x180/30fps/180frames/6秒の生成を確認。出力画素は動画区間green／写真区間cyan、原音880Hzを確認。0.57s動画は必要OUT2.20sのため理由を示して確定を無効化。元のCOLORタブへの復帰、英語種別ラベル、393pxで横overflowなしも確認。証拠export-verification.json参照。実機Safari未検証。
- 動画／静止画の追加証拠 ../.codex-context/audit-evidence/visual-replacement/。
- 証拠 ../.codex-context/audit-evidence/relink-replace/。Feature LabとSUMIKA移植成果物は非変更。

## 2.2.67 — iPhoneの通常削除と詰めて削除

iPhone下部に通常の「削除」を戻し、「詰めて削除」と併設。Macと同じ既存コマンドを使用します。6ボタンの横幅配分を調整し、プレビュー／タイムラインの高さを維持します。

- npm test全71本・build・diffcheck成功。通常削除と詰めて削除の後続位置を直接確認。既存Undo／Redo・プロジェクト復元試験も成功。
- 実ブラウザーの隔離表示で日本語／英語の320／393／430px幅を確認。320pxで発見した文字のはみ出しを幅配分と10px文字で修正し、水平・垂直はみ出しなしを確認。行の高さは維持。実機Safariは未確認。
- native20本成功。server試験は表示検証サーバーとの8876ポート重複を解消して単独再実行で成功。アプリ処理エラーではありません。ログ /tmp/pve67-*、証拠 ../.codex-context/audit-evidence/release-2.2.67/。

## 2.2.66 — 削除後の描画資源・素材参照の解放（2026-10-15）

- 映像クリップがなくなった時に、主／下位／トランジションの描画資源、静止画bitmap、主・待機videoのソース、動画の未完了読み込みを一度だけ解放。音声の再生系はこの経路では変更せず、音声・テロップ・FXだけのプロジェクトも維持します。全体メモリ解放も同じ画像解放処理を使用し、読み込み世代を進めて古い結果を無効にします。
- LOOKサムネイル描画器はLOOK以外のタブへ移る時とメモリ解放時にdispose。次に開いた時に再生成します。
- media-resource-cacheを追加。現在／Undo／Redoに必要な素材を保持し、不要なFile・Blob URL・サムネイル・配置先情報を整理。履歴を増やすcheckpointで、Redoを消す前に確認することで、ドラッグ取消時の復帰を保護します。新規取り込み中は解放を見送り、未登録のサムネイルを消しません。履歴の素材IDは記録・再利用し、全履歴のJSON解析を毎回繰り返しません。履歴が不正なら解放せず安全側に倒します。共有URLを使う現素材やMac素材ID／元ファイルには触れません。
- 静止画の再読み込み後に必要な再描画を行い、遅着した削除済みクリップの画像は表示しません。
- 新規resource-lifecycle試験：Undo/Redo、取り消しと旧Redo、履歴失効、新規import、共有URL、native URL、不正履歴、120回の空drawで再解放なし、静止画再取得と再削除、遅着抑止、音声だけのproject、LOOK再生成。既存text-renderの実メモリ解放試験も共通helperを通すよう更新。
- 公開前npm test・build・diffcheck成功。/tmp/pve66-{npm,build}.log。3,000回の素材追加・削除・Undo／Redoの連続試験で、履歴中の全素材保持と、履歴失効後のURL一回解放を確認。/tmp/pve66-history-stress.log。native/音声の書き出しロジックは非変更。
- 隔離実ブラウザで画像配置→最後のclipを詰めて削除→Undo→画像復帰、LOOK一覧9枚生成→BASICへ移動→LOOK9枚再生成、音声付き動画の削除→Undo→再生位置5.13秒→6.50秒で停止を確認。console errorなし。音声は自動回帰試験で停止・復帰経路を確認、実機で聴覚による確認は未実施。
- 公開前ネイティブ20本（映像・音声・LOOK・FX・レイヤー・復元・server・各形式）成功。Mac ZIP CRCとapp／新資源モジュール／engineソース一致を確認。/tmp/pve66-native-results.json、/tmp/pve66-package.log。ローカルFFmpegにない任意機能は利用不可経路を確認し、対応機能の実処理と区別しています。
- 実iPhone SafariのGPU使用量・長時間編集のメモリ推移は未確認。手ぶれ補正／文字Canvasの下記修正も同じ版へ収録します。

## 手ぶれ補正・テロップの不要リソース解放（2026-10-15・2.2.66）

- StabilizationPreview.reconcileで現在のクリップ・素材ファイル・範囲・補正設定に必要なキーだけを残す。タイムライン更新時に実行し、OFF/削除/静止化/範囲変更/再リンクで不要になったpending worker、cache、failedを除去。ensureで同じclipの旧条件も停止する。
- 中止後のprogress/done/errorと、clear後に同一キーで再開始した場合の古い結果を、pending workerの同一性で無視。ほかの有効な解析・完成した経路は保持する。
- プロジェクト読み込みはsanitize成功後に旧解析とテロップ領域を解放。不正なproject拒否時は既存編集・素材URLに触れない既存試験も成功。
- TextPreviewは空ならレイアウト/Canvas処理へ進まず、要素削除・非表示・1x1への縮小を行う。60空フレームでgetContext/clearRect/リサイズ/レイアウト読取0。再表示・削除・復元とメモリ解放後の再作成を検証。
- releasePreviewMemoryが補正解析と文字Canvasも解放。previewMemoryReleasedで予約済みの停止フレーム描画がリソースを直後に再作成するのを防止し、明示的なsyncVideoで解除。実app関数をVMで実行して解放・編集保持・描画再開を確認。
- 最終npm test/build/diffcheck成功。/tmp/pve-resource-cleanup-final-{npm,build}.log。音声・native・書き出しコードは非変更。実機iPhone/Safari・実GPUメモリ量とフレームレートは未検証。2.2.66へ収録。

## FOCUS削除後のプレビュー負荷（2026-10-15・2.2.65公開前検証）

- ユーザーがiPhoneでFOCUS削除後に重さが戻らないと報告。再生マスクの200vmax、範囲指定枠の100vmaxの巨大な影を廃止し、プレビュー内だけの4矩形に変更。範囲外を暗くする面積は同じ。実機のGPUメモリ残留そのものは未測定であり、原因を完全に断定しない。
- ズームなしはtransform:noneへ戻し、FOCUS削除時は再生マスク・指定中マスクともDOMから除去。空プロジェクトの早期returnでもFX表示を除去する。
- 使用していないLayerPreview.clearが毎描画でGPUテクスチャを再確保していたため、解放を1回に限定。初期非表示120回clearは解放0回、表示後120回clearは1回、再表示後のclearは再度1回を確認。非同期読み込み中のclear/pause回帰試験も成功。
- 100回のズーム復元/削除、FOCUSのマスク面積・境界を検証。npm test/build成功（/tmp/pve-fx-recovery-{tests,build}-complete.log）。音声・書き出し処理は変更なし。
- 隔離ポート8873、393x852の実ブラウザUIでFOCUS追加→削除→Undo→Redo。マスク/指定中マスクの要素0、両transform:none、指定枠の影は1pxだけ、再生0.20秒進行→2秒終端停止→再生し直して0.11秒で停止を確認。console errorなし。ユーザーの公開版/編集データは非変更。
- 証拠 ../.codex-context/audit-evidence/focus-preview-recovery.png。初回8872は開発中の古いCSSが残ったため8873の新originで最終コードを確認。実iPhone Safariでの負荷回復・長時間/高解像度・実音は未検証。2.2.65の公開用キャッシュを更新し、Mac ZIPも同じソースへ更新する。

## 公開前のFFmpeg互換性確認（2026-10-15）

- Ubuntu CIで、映像コピーと音声エンコードを同じ出力時間で終了すると音声が短くなる問題を検出。中間WAVは2秒で揃っている一方、最終AACだけ1.941秒（範囲ズーム時は1.834秒）になることを各段階のメタデータで確認した。
- ミックスを作品のサンプル長で確定し、音声を独立してエンコードしてから映像とコピー結合する。映像の再圧縮回数・画質設定は増やさない。必要な最終映像フィルターも一度だけ適用する。
- 素材解析FX試験は、FXなしを基準に全デコード音声サンプルの一致、2秒分以上のサンプル数、末尾100msの有音を検査する。生成素材の尺も明示し、失敗時だけ中間データを表示する。
- Macの12条件は全映像画素と作品時間内の音声サンプルが従来基準と一致。速度変更ケースでは作品時間外のAAC余剰データが異なるため、生デコード全体のハッシュではなく作品時間内のサンプル一致も個別確認した。

## Mac書き出し高速化・既存不具合修正（2026-10-15・ローカル検証）

- 同じ20秒・125項目の複雑プロジェクト、1080×1920/30fps/High/libx264 fast CRF18。M2 Maxで本体実装の実測81.886秒。従来536.115秒から約84.7%短縮。約78秒の試作と完成動画600フレームの全画素・音声全サンプルSHA256一致。試作値と本体値を混同しない。
- 最初の画面FXの単独処理でCFR時刻を維持し、以降を一括処理。FX入力数は1080pで最大32、4Kで最大8に制限。不要な下地生成を省くが、トランジションがある場合は省略せず元の下地を使用する。
- 静止画の1フレーム処理は移動・拡大アニメーション／サイズポイント指定のない場合のみ。映像クリップの並列は最大4、プレビューは1、4K素材・ProResは最大2。使い回す手ぶれ補正・音声ランプ一時ファイルの入力は逐次処理。結合・遷移合成の前に全完了を待つ。
- 12条件を本体でも比較し、画素・音声の一致を確認：24/30/60fps多層alpha、速度変化/VFR/5.118倍速/静止保持、人工PQ10bitのHDR変換、非表示/ソロ、FX/文字固定の範囲ズーム、ProRes、4種類の遷移、遷移の上のalpha、静止画フェード・サイズポイント。画面FXはCFRを保持する2回試作が比較基準、他は旧エンジン。ProResの10bit一致は詳細監査でも別途確認。
- 画像のPANでpadが時刻式を評価できず失敗する問題を、固定の余白と動くcropで修正。黒背景上で縮小画像が上下左右に動くことを画素重心で確認。
- 極短いalpha多層＋遷移で1フレームがfps処理から落ちる問題を修正。最初は一般クリップへも影響したため、保持処理を1フレームだけのalpha合成に限定し、全編一致を再確認した。24/30/60fpsのフレーム数・全decode検証を追加。
- 親キャンセルを全ワーカーへ伝播し、進捗を出さない子プロセスも停止。待機中ジョブの取消を通常エラーと区別し、全プロセス終了後に一時領域を片付ける。スクリプトの独立性・キュー上限・エラー伝播・回復数集計・取消をtests/export-optimizations.test.pyへ追加し、CIでも実行する。
- npm test/build成功、native全20本成功。server.test.pyは初回のsandbox待受拒否を切り分け、ローカル待受を許可した再実行で成功。関連ログは/tmp/pve-integrated-*、/tmp/pve-export-optimizations-final.log、workspace/pve-export-benchmark/quality-audit/。
- 隔離したローカル実アプリでプロジェクト読込→プレビュー再生→Mac H.264書き出し→全フレーム/音声検証済み画面→編集へ戻りSpace再生→終端停止を確認。既存編集データは未変更。物理スピーカーでの実聴ではない。
- 実Safari本体・実iPhone・実写HDR・長編4K・編集と書き出しを同時に行う際の負荷は未確認。GitHub/公開サイトは未更新。未公開2.2.64のエンジン改修として収録。

## 2.2.64 素材解析FX・保存復元・書き出し（2026-10-14公開前検証）

- URL素材解析はメイン画面で全体Blobを作らず、ワーカーのUrlSourceを利用。File/URLの両経路をブラウザで確認。Macパッケージも生成・検証成功（/tmp/pve-material-mac.log）。
- 純粋関数試験: 無音/一定音の除外、音の立ち上がり、一定パンの除外/急な動き検出、揺れ量による抑制、テクスチャ追跡/低信頼度保持、経路補間/範囲制限/最大80点、保存復元、元素材編集時の無効化、再生で経路を複製しないことを確認。
- 全npm test/build成功。ログ/tmp/pve-material-js-final.log、/tmp/pve-material-build-final.log。
- native実書き出し: 新4FXとFOCUS＋ZOOMの組み合わせをH.264/AACで検証。画素、全decode、2秒の尺と音声RMSを確認。ログ/tmp/pve-material-native-final.log。既存REGION ZOOMのテロップON/OFF・透明合成とcreative動画処理も成功（/tmp/pve-material-{region,creative}-native.log）。
- CUA実worker: 2秒の静止テクスチャを横パン＋一度急移動させた動画で、追跡経路・不確かな点0・急な動き候補1を確認。右チャンネルのみの音声で0.4/1.0/1.6秒の3アクセント検出。速度0.5倍の時間対応も成功。
- 端末内4FXを書き出して再decodeし、同じ素材のHTMLVideo/GPU＋Canvasプレビューと画素を比較。160×90の高周波テスト素材は圧縮誤差を分離するため8Mbps指定。平均誤差は0.99〜3.83/255、全FXで画面変化と出力検証成功。既定ビットレートの低解像度人工ノイズ動画に対する画素完全一致は主張しない。
- 実編集画面で音アクセント/バンプ/追跡ズームの解析適用、iPhone幅393でFOCUS枠指定・追跡適用、解析結果Undo/Redo、横overflowなしを確認。証拠../.codex-context/audit-evidence/material-fx-{result.json,phone.png}。
- 実機iPhone Safari、実写での隠れ/顔変形/高速運動/HDR、長い解析区間の性能は未確認。追加の常駐解析なし。音声プレビュー/mix/export処理非変更（キャッシュ番号以外）。元Mac開発版は非変更。2.2.64の公開対象へ追加。

## 2.2.63 公開前検証（2026-10-13）

- 前回からの操作中断復帰修正、iPhone共通リセット、通知3.4秒、LOOK回帰検証を収録。
- タイムラインの前詰めボタンを「詰めて削除」に変更。iPhoneの同じ処理につながる「削除」表示も揃えた。機能そのものは変更なし。Shift+Deleteと英語Ripple deleteを維持。
- npm test全体・npm run build・git diff --check成功。native全17本（LOOK/localhost API含む）、Mac ZIP検証成功。ログ/tmp/pve-release-63-{js,build,native,mac}.log。実機Safari/ユーザー素材HDRは未確認。

## iPhoneリセット・通知短縮・LOOK書き出し検証（2026-10-13・未公開）

- iPhone上部に既存resetAllボタンをSVGアイコンで表示。Macと同一のconfirmResetAll/resetAll処理を利用。Macの文字ボタン表示を維持。
- 通常toast共通時間を4400→3400msに変更。同程度の独立した情報通知タイマーは見つからず。処理タイムアウト/保存待ち時間は変更なし。
- CUA393×852でリセット確認の消去対象/素材非削除/保存リンク/キャンセルを確認（リセット実行なし）。上部右端385px、画面幅393px内に全ボタン収まる。LOOKカードMONO選択と強度1.00確認。
- 実書き出し: tests/look-export.test.pyでMac全9LOOK、MONO強度0/.5/1、V3、完成動画decodeとH.264/AAC、元ファイルハッシュ維持を確認。ログ/tmp/pve-look-native.log。
- tests/fixtures/look-export.htmlは実アプリのrenderer＋mobile workerを用い、生成PNG/一定色H.264素材からMP4作成、再decodeした中心画素とプレビューを比較。全9LOOK、MONO0/.5/1、V3/合成経路、動画MONO/WARMがPASS。差は0〜3/255程度。検証出力ファイルは終了時削除。動画プレビューはアプリと同じHTMLVideoを使用し、WebCodecsの別描画経路と混同しない。
- LOOK未反映は今回再現せず、LOOKのproduction処理は変更していない。iPhone実機Safari・ユーザー素材/HDR未確認。
- npm test全体/build成功、証拠: ../.codex-context/audit-evidence/phone-reset-header.png、look-export-result.json（ブラウザ検証結果）。

## プレビュー操作・境界調整の追加監査（2026-10-12・未公開）

- stage-transform: 操作中の別pointerdownで進行中のドラッグを上書きしない。lostpointercaptureでも既存の終了処理を実行し、ガイド・ドラッグ状態を解除。中断時の変更確定は既存pointercancelと同じ仕様を維持。
- workspace-splitter: 所有pointerだけで調整・終了。cancel/lostcapture時は元の比率へ復帰し、途中値を保存せずCSS/handlerを解除。
- 回帰テストで別pointer干渉、captureloss、二重終了防止、解除後の再操作、正常完了保存を確認。
- 素材プレビュー、設定reset、タブrouting、プロジェクト保存復元の実装と関連テストも点検。今回それらの明確な不具合は確認せず。
- npm test全体/build/diffcheck成功。ログ/tmp/pve-third-audit-{test,build}.log。再生/音声/export非変更。ブラウザ実操作・実機Safariは未検証。

## 操作不整合の追加監査（2026-10-12・未公開）

- パネル開閉・素材プレビュー・読み込み・再生開始/停止/シーク・書き出し復帰・Undo/Redoの実装と関連テストを確認。
- Macパネル幅調整: 別pointerのmove/up/cancelを無視。cancel/lostcaptureで元の幅へ復帰し、ドラッグCSS状態とハンドラを解除。途中値を保存しない。通常完了の保存は維持。
- 新回帰テストで左右両方のパネルについて別指・captureloss・取消・再操作を検証。
- 前回のクリップ/FX/レイヤー高さ修正を含むnpm test全体、npm run build、git diff --check成功。ログ: /tmp/pve-expanded-audit-test.log、/tmp/pve-expanded-audit-build.log。
- 再生・音声・書き出し処理は変更なし。今回ブラウザでの実操作、実機Safari、実素材書き出しは未実施。

## 2.2.62 — 映像・音声のドラッグ表示をFX方式へ統一

固定top:2px!importantがドラッグのstyle.topを上書きする原因を修正。FX同様のtranslateYで実高さへ追従し、完了・取消・capture喪失で移動表示を解除。複数選択の随伴クリップも同方式。ブラウザで実CSS使用の手動fixtureを検証：映像V1→V2は-52px、音声A1→A2は44px、描画位置は宛先top+2pxと一致。通常幅と393pxの両方で成功（マウス入力）。全68JS/build成功、実機Safari touch未確認。fixtures/timeline-drag-visual.htmlをrepo rootのHTTPで再検証可能。音声再生/export非変更。公開前追加検証：Python動画処理16本・localhost API成功、Mac ZIP 4,210,892 bytes検証成功。

## 2.2.61 — タイムライン操作の修正（2026-10-12）

- 映像／音声の移動とIN/OUTトリムで、他種のクリップ端も吸着対象に統合。移動グループと、映像に追従する連動音声は対象から除外。
- 移動先の段・左見出しを強調しV/A番号を表示。段の境界では最後の有効な移動先を保持。非表示の段は対象外。完了・取消・capture喪失後の強調解除を検証。
- 音量ライン単押しでは点を追加しない。ダブルクリック／ダブルタップで追加。既存の点の上下・左右調整は維持し、明示的なレイヤー移動モードを優先。点のcapture喪失時にハンドラ解除。
- npm test（68ファイル）とbuild成功。単押しと二度押し、選択によるDOM交換、ドラッグとの排他、映像／音声の吸着・取消後復帰を追加検証。
- CUAのMac画面で映像V1→V2、音声連動解除後A1→A2、音量ラインからの段移動、音声OUT端→映像OUT端の吸着を確認。表示上の右端差0.008px（丸め差）。393×852で横はみ出しなし。証拠はworkspaceの.codex-context/audit-evidence/timeline-audio-edge-snap.jpg。
- 音声再生／書き出しの実装は非変更。iPhone実機Safariのタッチ確認は未実施。版とキャッシュキーを2.2.61へ統一。公開前の追加検証：Python動画処理16本（localhost API含む）成功、Mac ZIP 4,209,224 bytes検証成功。

## 2.2.60 — iPhone範囲ズームの直接枠操作（2026-10-12）

- FX設定中のプレビュー操作を開放した前回修正を維持。枠dragとresizeにtouch moveのpreventDefault/stopPropagation、pointerIdの一致確認、lostpointercapture時の取消/復帰を追加。Macの枠計算・出力処理は維持。
- iPhoneのresize hit targetを44pxに拡大し、画像の端でも枠border分を含めて内側へ収める。小さい枠にはresizeと重ならない74×44pxのZOOM移動つまみを表示。通常枠は従来どおり枠内をドラッグ。
- 新回帰テストは旧実装で別pointerが枠を変更して失敗。修正後はtouch move/resize、別指除外、scroll抑止、capture取消/次操作、四隅のhandle座標、移動つまみとresizeの分離が成功。
- 393×852ブラウザで直接drag移動（横位置0.50→0.63）、resize（size0.40→0.27→0.10）、最小枠の右下端配置、ハンドル全44pxの画像内表示、ZOOMつまみからの再移動、reset0.40を確認。入力はマウス。実機Safari touchは未確認。
- 証拠 workspace .codex-context/audit-evidence/phone-region-zoom-direct-frame.jpg。npm68/build成功。公開用追加検証はリリースログへ記録。

## 2.2.60 — iPhone FX設定とタッチ操作の復帰（2026-10-12）

- 範囲ズームの「テロップもズームする」を時刻・枠スライダーより前へ移動。選択FXの設定を先頭に出す処理をHTML生成へ一本化。22pxチェックボックス／44px行を確保。FX設定中のプレビューのinertを解除。
- タイムラインの管理対象タッチはルートだけがpointer captureを保持。映像・音声・テキスト・FXの委譲ハンドラはcaptureを奪わない。直接のトリム／Mac操作は従来の要素captureを維持。
- rootのlostpointercapture、次のprimary pointer、表示切替、blur/pagehide、切り離されたクリップDOMで古いgestureを解除。終了時は状態を先に破棄してから完了／取消を呼び、再描画からの再入を防ぐ。ピンチによるDOM更新は解除対象から除外。
- 回帰テスト追加前はlostpointercaptureの解除ハンドラ不在で失敗。修正後は20回のcapture中断・復帰、シート切替、up欠落、切り離されたDOM、バブリングした子のcapture loss、ピンチ中DOM更新、通常／管理対象のcapture分離が成功。
- npm test（68ファイル）／npm run build成功。再生・音声処理／書き出し処理は変更なし。
- 393×852のブラウザでFXのON/OFF、チェック行の表示範囲、横はみ出しなし、TEXT再編集8回後のシート閉鎖／timeline inert解除／映像クリップ選択を確認。FX中viewer inertなし、timeline inertありを確認。
- ブラウザ操作はマウス・DOM操作。iPhone実機Safariのタッチ操作は未確認。証拠 .codex-context/audit-evidence/phone-region-zoom-touch-fix.jpg（workspace root）。公開結果は引き継ぎstateへ記録。

## 2.2.59 — 範囲ズームFX

範囲ズームのgeometry/保存復元と、Mac出力の画素・透明テロップ・戻り/保持・音声を検証。実機Safari再生と端末書き出しは未確認。

## 範囲ズームとテロップの追従（2.2.59）

zoomTextsをFXごとに保存・復元（未設定はオン）。JSの初期値・保存復元を検証。FFmpeg出力の追従オン／オフでテロップ画素位置を確認し、透明背景が映像を覆わないこと、設定混在時の透明ズーム合成、全デコードを検証。環境のFFmpegにdrawtextがなく、ブラウザ文字画像で確認。iPhone実機の再生・書き出しは未確認。

## 範囲ズームFX（2.2.59）

時刻・瞬時切替・戻り／保持・枠境界・プロジェクト再読込・Canvas合成を単体検証。Mac FFmpeg出力を全デコードし、対象画素・戻り／保持・映像時間・音声の存在と長さを確認。CUAで枠移動、サイズスライダー、戻り選択、リセットと393pxで横はみ出し無しを確認。iPhone実機Safariと端末MP4書き出しの実機確認は未実施。

## 2.2.58 — iPhone設定画面の統一

CSS整理前後を9画面で比較。393px日本語／320px英語で表示を確認し、Macの補足文字と再生操作を確認。実機Safariは未確認。

## 2.2.57 — Macプレビュー下部の一段化

CUA1512×850でプレビュー約30px拡大、操作群の縦中心一致。1280×720／1024幅で重なり・横はみ出しなし。再生停止・先頭・フレーム送り・比率切替を確認。iPhone393幅の配置維持。npm67/build、Python映像音声server15、MacZIP4,193,504bytes成功。元Mac161SHA差分0。実機Safari未確認。

## 2.2.56 — Macの文字階層・設定UIの統一

主要9タブを1512×850日本語／1280×720英語で点検。テキスト全グループ、FX・音声詳細、素材詳細、ヘルプ・書出し・エンジン・プレビュー設定を確認。iPhone幅も横はみ出しなし。npm全67/build、Python映像音声server全15、MacZIP4,192,914bytes成功。元Mac161SHA差分0。実機Safari未確認。

## 2.2.55 — Mac下部と14インチ表示の調整

CUA1512×850でプレビュー約9px拡大、タイムライン約2px減少。1280×720、1024幅、JA/ENで横はみ出しなし。分類ラベル間隔2px、再生開始停止、iPhoneheader40/disc32維持を確認。実機14インチSafari未確認。npm全67/build、Python映像音声server全15、MacZIP成功。元Mac161SHA差分0。

## 2.2.54 — Macの固定UIとライブラリーをコンパクトに

CUA1440/1024でタブ枠内、分類名との間隔2px、横はみ出しなし。英語表示とiPhone393でheader40/tools44px維持を確認。実機Safariは未確認。npm全67/build、Python映像音声server全15、MacZIP成功。元Mac161SHA差分0。

## 2.2.53 — iPhone操作列の余白と再生ボタン

CUA393/320で横はみ出しなし、編集パネル境界一致、再生開始と停止を確認。実機Safariは未確認。npm全67/build、Python映像音声・server全15、MacZIP検証成功。元Mac161ファイル差分0。

## 2.2.52 — iPhoneプレビュー配分の統一

393×852でBASIC/MOTION/COLOR/LOOKS/TEXT/FX/MIXのプレビュー高さ一致、320×740で境界一致・横はみ出しなしをCUA確認。実機Safari未確認。npm test全67/build、Python映像音声・server全15、Mac ZIP検証成功。元Mac161ファイル差分0。

## 2.2.51 — iPhoneの一列ツールメニュー（2026-10-11）

公開前検証：JavaScript全67、build、Python映像・音声・localhost server全15、Mac ZIP検証成功。元Mac161ファイルのSHA-256差分0。

- LIBRARY/BASIC/MOTION/COLOR/LOOKS/TEXT/FX/MIXを一列の横スクロールへ。その他は右端固定。左右矢印はタップで移動、続きのある側だけ有効にし、端にフェードを表示。項目を一部見せて横の続きが分かる配置。初回案内なし。
- 選択ツールを自動で見える位置へ移動し、選択色とaria-currentで識別。MOTION/FXをその他から移し、ANALYZEはその他に保持。専用SVGのmotion/fx/矢印追加。高さ46px維持。
- CUA393×852で矢印移動0→198→237px、FX選択、選択維持、その他固定x339、パネル復帰、その他内容を確認。320×740でnav横overflow0、その他右端318px、height46px確認。
- npm test全67、build、diff-check成功。実機Safariの指スワイプは未検証。公開対象のコードです。証拠：作業ルート.codex-context/audit-evidence/tool-strip-{start,end}.jpg。

## 2.2.51 — Mac／iPhoneタブ名統一（2026-10-11）

- iPhone映像調整をMacと同じBASIC/MOTION/COLOR/LOOKSに統一。LIBRARY/TEXT/MIX/FX/ANALYZEの入口・パネル名も揃え、workspace-uiの共通メタデータから表示。スマホ固有の「その他」「レイヤー」等は維持。
- 393×852と320×740のローカル実ブラウザで4タブ・下部7ボタンのscrollWidth=clientWidthを確認。COLOR/LOOKS切り替えで見出しも追従。パネル寸法と映像・音声経路は変更なし。
- npm test全67スイート、build成功。実機Safari未確認。画像：作業ルート.codex-context/audit-evidence/tabs-unified-iphone.jpg。

## 2.2.51 — iPhoneパネル切り替えの操作復帰（2026-10-11）

- 「その他 → モーション」でviewer-panelのinertが残り、閉じた後も再生・シークを操作できない状態をローカル実ブラウザで再現。パネルの切り替え前に既存の操作禁止範囲を解除し、各要素の元のinert値を復元する小さな管理関数へ統一。
- 上部の書き出しボタンを詳細パネルでも操作可能にし、クリックのcapture段階でパネルを閉じてから既存の共通EXPORT SETTINGSへ進める。書き出しエンジン・映像時計・音声経路は変更なし。
- 393×852のCUA実ブラウザで音声付き12秒H.264/AACテスト素材を使用。5.118倍・2倍・0.05倍の再生開始と時計の進行、2倍のvideo playbackRate、モーションから戻った後のinert残留0を確認。1倍と5.118倍で共通書き出し設定の8項目とパネル解除を確認。
- npm test全67スイート、npm run build、git diff --check成功。操作範囲の切り替え・閉じる・元からinertな要素の維持を回帰試験へ追加。
- 実機iPhone/Safari、今回の実ブラウザMP4生成・音の聴取は未確認。証拠：phone-motion-play-fixed.jpg、phone-export-panel-fixed.jpg（作業ルート.codex-context/audit-evidence）。

## 2.2.50 — 英語UIと領域内表示（2026-10-11）

- 固定／動的ラベル、素材・レイヤー・カラー・モーション・音声・書き出し通知・設定・ショートカット・ヘルプに英訳を追加。文中の既知の複数文もまとめて翻訳し、後から追加したDOMと属性を対象限定で更新。
- DOMの原文と表示文をWeakMapに保持してJA/ENの往復を復元。ユーザーの素材名・プロジェクト名・テキスト、入力欄を保護。既存caption内容は保持、新規captionの初期文言だけ表示言語に合わせる。
- 英語UIの長い説明／ボタンは設定内で折り返し。iPhone操作段を維持、メニューgridをminmax(0,1fr)にし、ラジオ入力の占有幅を抑制。
- CUAの実ブラウザで393×852と1440×900を確認。テスト用device-test.mp4をローカルへ読み込み・配置し、素材、カラー、モーション、基本、テキスト、その他、プレビュー設定、ヘルプを確認。メイン／その他／設定の横スクロールと対象ボタンの横はみ出し検査0。画面サイズはエミュレーションで、実機Safariではない。
- i18n試験で動的文言、JA/EN往復、原文更新、ルート属性、ユーザー内容の除外を確認。既存再生・音声・書き出しの回帰試験とPython動画処理全15試験成功。元Mac版は未変更。
- 記録：.codex-context/audit-evidence/en-50-iphone-settings.jpg、en-50-mac-help.jpg。全状態・全エラーメッセージの実ブラウザ走査、実機Safariは未実施。

## 2.2.49 — 再生の例外・競合修正（2026-10-11）

- 音声native playの同期throw／非同期rejectを世代と素材キーで判定し、出力を閉じてclockからエラーを通知。古いrejectは新しい再生に伝播せず、次の再生開始で状態を初期化。
- 2回目syncVideoの完了後にセッションを再確認してから失敗時停止。古い完了が新しい再生を止める経路を修正。
- currentTime代入を待機処理内で実行し、同期失敗時にイベントとtimerを解放。既存のイベント順序・AbortSignal・timeoutは維持。
- playback-failure.test.mjsに同期／非同期音声失敗・再試行・古いreject・映像準備競合・シーク例外cleanup・事前abortの試験を追加。JS全67スイートと静的build成功。音声立ち上がり・EOF・シーク・5.118倍速・通常decoder待ちの既存試験も成功。
- Python動画処理全15試験・localhostサーバー成功。Mac ZIPの内部バージョン照合と整合性検証成功。元Mac開発版161ファイルSHA差分0。
- iPhone実機／実Safari・聴感・長時間編集は未検証。端末書き出しworkerのreader.close例外によるcleanup中断リスクは今回の3件とは別で未修正。

## 2.2.48（公開済み）— 高速プレビュー時計・Shift操作

5.118／20／0.05倍の停止中decoderを時計から除外。通常再生のdecoder待ちを維持。Shift単独と複合キー・pointer・入力ガードを試験。npm test/build通過。ユーザーは2.2.47の書き出し解消を確認。Python動画処理・localhostサーバー・Mac ZIP検証も通過。実ブラウザのプレビュー復旧確認は未実施。ユーザーの明示承認後に公開済み。ユーザーがプレビュー復旧を確認。

## 2.2.47 — DEVICE ENGINEの容量判定修正（2026-10-11）

- 画像の「書き出し用の空き容量が不足しています」は、OPFS書き込み前のstorage.estimateとビットレートからの推定値比較で発生する文言と特定。推定値だけの中止を除去し、実際の書き込み結果で判定。元環境が本当にOPFS上限へ達していたかは未確認。
- 新mobile-storage-output.jsで部分書き込みを続行し、0バイト／異常な結果を保存失敗として扱う。実QuotaExceededErrorはMac本体とは別のブラウザ保存制限であることを表示。失敗ファイルを除去し、close例外が元の失敗原因を隠さないようにする。
- export-storage.test.mjsで推定quota満杯でも書き込みを開始、部分書き込みのバイト位置・元配列offset、実quota例外とその他のエラーの区別、開始失敗cleanup、V3の5.118倍速（104.406秒→約20.400秒）を検証。npm test/buildとgit diff --check通過。
- Desktopの該当movを非変更でffprobe／同梱Mediabunnyで解析。H.264／1350×1822／音声なし／28,509,275 bytes、全3,571パケットの時刻を確認。Mediabunny尺177.075秒、全尺5.118倍時34.598秒・推定約30MB（画像の20.40秒とは編集範囲が異なる）。元.movを使ったブラウザ書き出し・実機Safari／OPFS上限の実測は未実施。2.2.47として公開し、Mac ZIPも更新。

## 2.2.46 — 全体点検で確認した7件の修正（2026-10-09）

- 保存一覧の取得失敗時は未使用素材削除を中止。DB接続は成功・失敗のいずれでも解放し、接続ブロック・タイムアウト・遅延接続完了を扱う。
- 前詰めトリムに既存のtrimClipとsyncLinkedAudioを使用。速度カーブ・音量エンベロープを保持し、後続映像に連動する音声も移動。
- フォルダ保存は呼出時のスナップショットを順番に書き込み、古い保存による上書きを防止。失敗後の次の保存も継続。
- 下位映像プレビューの非同期準備は停止・解除の世代を確認してから再生。高さ変更後の複数クリップドラッグは、各レイヤーの実際の座標を使用。
- tests/audit-regressions.test.mjsで7件の再現条件、一覧読取失敗、blocked後の遅延接続解放、保存中のモデル変更・保存失敗後の回復、準備中の停止・解除・再開、映像／音声の可変高さ、IN／OUT速度カーブ・音量ポイントを検証。npm test／build、git diff --check成功。元版161ファイル差分0。
- 検証はNode上のモックDB・ファイルI/O・メディア・DOMを使用し、利用者の保存データは操作していない。実機Safari、実フォルダでの並行保存、長時間編集は未検証。Mac ZIPを2.2.46で生成・検証。公開時も実機未確認事項は維持。

## 2.2.45 — 再生開始音・状態管理の堅牢化

実OfflineAudioContextで開始サンプル0、5msで中間音量、20msで設定音量を確認。実音源を途中から3回反復再生し、ディレイ無効／有効とも初回開始・終端1秒到達、JS例外0。遅いplay完了が出力を再開しないこと、masterの同一設定を繰り返さないこと、ディレイのみを再生成しMediaElementSourceを二重接続しないことを試験。シーク位置確定を共通化、未使用_seekTargetを除去、準備失敗時に並行読み込みを中止しfinallyで状態を解放。npm test/build、Pythonパイプライン・サーバー試験通過。元版161ファイル差分0。記録：validation/audio-start-45.png。iPhone実機の短い雑音そのものは未再現で、改善の実機確認は未完了。

## 2.2.44 — シーク後の初回音声・終端同期

旧処理で初回読み込み中の連続シーク試験が失敗。修正後は指定位置を保持し、準備完了前の時計開始を防止、準備キャンセルも通過。実ブラウザーの1.00秒WAVを0.20／0.55秒から再生し、どちらもplay1回、終端1.000秒。既定の末尾消音は最後8msのみ。Mac編集画面のシーク後初回再生で時計0.22秒への進行を確認。npm test/build、Pythonパイプライン・サーバー試験通過。iPhone実機・ユーザー素材は未確認。記録：validation/audio-seek-44.png。

## 2.2.43 — 素材終端の自動再開を再現・修正（2026-10-09）

- 修正前のコードに対し、2.00秒の実音源を編集上2.05秒とした試験が「Mac must not restart ended source」で失敗（play 2回）。修正後はiPhone／Macとも再開0、終了済み音源の消音・位置2.00維持、明示的な再生は成功。
- 実ブラウザーでWAV0.60秒、編集0.80秒を旧2.2.42／修正版で比較。旧iPhoneは3秒後も時計0.60秒・play5回・未終了。旧Macも終端付近でplay5回。修正版は両方play1回・時計0.80秒・自然終了・全音源mute・AudioContext suspended。JS例外0。
- 編集画面393×650と1440×900で17.60秒の終端直前から自然終了し再生ボタンへ復帰。終了後の明示的な再生は時計0.23秒で停止ボタン、停止・再開後0.49秒へ進行。JS例外0。
- EOF後のラッチ、新クリップ・明示シークでの解除、終了した時計の解放、意図的なループの維持を試験。映像／下位プレビューにもEOFラッチを適用。予期しない再生フレームの例外はpauseで出力を閉じる。
- npm test／build、Python動画パイプライン・サーバー試験、Mac ZIP生成検証通過。元版161ファイル差分0。
- 記録：validation/playback-end-browser-43.json、validation/playback-end-browser-43.png。iPhone実機とユーザーの元の素材では未確認。

## 2.2.42 — 停止後の残留音対策（2026-10-09）

- 音声回路を接続する前にfeedback／wet／outputを0、delayを0.28秒へ初期化。全voiceの出力を共通master経由に統一。
- 停止でmasterの予約を取消・0を設定、音源をmute・pause、feedback／wetの予約取消、AudioContext.suspend。停止中syncが音声回路を再設定しない試験を追加。
- 保留中play完了の消音維持、保留中suspendを待って次のresumeを実行する試験通過。
- ブラウザーの実AudioContextでrunning→suspended→running→suspendedを確認。suspend直後のAudioParam.valueは処理前の値1を返すため、停止の確認はcontext.stateと全音源のpaused／mutedで行った。ユニット試験で0設定・予約取消も確認。
- iPhone幅393×650で動画の自然終了17.60秒、停止直後の再開と時計進行、JS例外0を確認。iPhone実機の破裂音そのものは未再現・未確認。
- npm test／build、Python動画パイプライン・サーバー試験、Mac ZIP検証通過。元版161ファイル差分0。

## 2.2.41 — 素材カード内の配置先（2026-10-09）

- iPhone幅393×650でカードから動画V3へ配置。別カードのV2選択と他カードのV1選択を保持、詳細の「V3の末尾へ配置」も一致。選択だけでは配置しないことを確認。
- 音声カードから空のA4へ配置し、A4レイヤー・クリップの表示を確認。中央の配置先ボタンは0個。
- 320×650・393×650とも横幅超過0、カード操作欄のscrollWidthとclientWidth一致。Mac1440×900ではカード内セレクト0個、従来の配置ボタンを維持。
- npm test／build、Python動画処理パイプライン・サーバー試験通過。Mac ZIP生成検証。元版161ファイルのSHA-256差分0。
- iPhone実機Safariでのネイティブ選択メニューは未確認。配置先は編集中のセッション内で素材ごとに保持。
- 記録：validation/iphone-card-layer-41.png。

## 2.2.40 — 編集点の移動・選択・吸着（2026-10-09）

- マーカー・ジェスチャー試験を追加。mouse／touchのクリック選択（詳細は開かない）、4pxのドラッグ判定、1ドラッグ1履歴、移動限界、キャンセル／キャプチャ喪失で復帰、詳細操作を確認。移動・削除でクリップ不変、移動後の時刻順と保存読込を検証。
- 映像／音声の移動時の両端と、IN／OUTトリムが編集点へ吸着する試験を追加。吸着OFFも確認。FX／文字の共通吸着先に編集点を追加。
- Mac1440×900でクリック選択・非モーダル、選択クリップ0、実ドラッグ1.06→4.26秒、Backspaceで編集点2→1（クリップ7維持）、Undoで復元、再読込で移動位置保持、詳細の秒数入力4.00を実操作。
- Macで8秒動画のOUTを4秒の編集点へ実ドラッグし、右端と旗中心の差0px。1.6秒動画を長さを変えず移動し、末尾を4秒の旗へ吸着（開始2.4秒・右端差0px）。
- 旗は時間目盛りの手前に置き、再生ヘッドと重なっても選択・再ドラッグ可能。共通ボタンhoverのtranslateYがX位置をずらす問題を専用CSSで修正、Macの旗と再生ヘッドのX差0px。
- iPhone393×650で旗クリック・選択文脈・実ドラッグ4→6.83秒、下部削除・Undo、再読込保持を確認。さらに8秒のクリップ境界へ旗を吸着、旗と再生ヘッド差0.004px未満。読み込み待ちでも時計を先に更新。旗は22×18px、320×650で横幅超過0。
- 最新ヘルプの表示、編集点・素材配置・高さ・戻し方・書き出し注意を確認。
- npm test全件、npm run build、Python動画処理パイプライン、サーバー認証・Range・保存・配信試験が通過。元版161ファイルはSHA-256差分0。Mac ZIPは配布時に生成。
- iPhone実機Safariの指操作・長尺多レイヤー再生中の連打・HDR素材は未確認。ブラウザUI試験の実ドラッグはマウス入力、touchジェスチャーはユニット試験。
- 記録：validation/mac-marker-snap-40.jpg、validation/iphone-edit-marker-40.jpg。

## 2.2.39 — 編集の目印とレイヤー高さ（2026-10-09）

- Mac幅1440×900で、動画を再生しMキーを入力。時計1.06秒で目印を追加、再生ボタンは「停止」のまま、時計1.08秒へ進行。再生継続とJS例外0を確認。目印の名前変更・削除・Undo・再読み込み保持を確認。
- Mac境界の実ドラッグでV2を52→102pxへ拡大。V1・A1は元の高さを維持、見出しと段の高さ／縦位置差0。ダブルクリックで52pxに復帰。
- iPhone393×650のA1を64→114pxへ実ドラッグし、波形キャンバス40→90pxへ追従。左見出しと段の縦位置差0。Homeで48pxへ復帰。A2の波形ジョブ完了も確認、Mac92px／iPhone80pxでキャンバス68px／56px。
- iPhone320×650で横幅超過0、A2見出しとの縦位置差0。A2境界を標準48pxの近くへ実ドラッグし48px・is-defaultへの吸着を確認。MacとiPhoneの表示高さを別保存。
- 境界へフォーカスした際に見出しだけがスクロールする症状をoverflow:clipで修正。境界キー操作は全体のシークショートカットから除外し、Homeによる高さ復帰前後で再生位置16.00秒を保持。
- ユニット試験：目印追加・時刻順・重複時刻抑止・前後移動・保存読込・不正値除去。高さの各標準値・吸着・ヒステリシス・上下限。スマホのスワイプが高さ調整の指を横取りしないこと。
- npm test／build、Python動画処理パイプライン、サーバー認証・Range・保存試験が通過。Mac ZIPは配布時に生成。元版161ファイルのSHA-256差分0。
- 静的Mac検証中、エンジン未接続の音声素材読み込みでタイムアウト表示が一度発生し、後から配置／波形生成が完了。ローカルMacエンジンでの同症状、iPhone実機Safariの指操作・聴感・長尺再生中の連打は未確認。
- 記録：validation/mac-edit-markers-lane-height-39.jpg、validation/iphone-lane-height-39.jpg。

## 2.2.38 — iPhoneの素材読み込み・レイヤー配置（2026-10-09）

- phoneImportの通常読み込みから自動appendMedia/useAudioを除去。同名の未配置素材の再選択でも自動配置しない。読み込み後は素材ライブラリを表示し、再生ヘッドを保持。通常音声も同様、BGM専用導線の明示的配置を維持。
- 素材タブにV1／V2／V3の選択ボタンを追加。targetLayerでactiveLayerを更新し、既存の配置ボタンからその段の末尾へ配置。空の段も選べる。素材のタップによるタイムラインへのシークもphoneでは行わない。
- 素材詳細のclose/Escapeを「素材一覧へ戻る」に変更。詳細を閉じる際に動画／音声試聴を停止し、一覧スクロールと選んだ配置先を保持。phone動画の詳細にcontrols付きplaysinlineプレビューを追加。
- 実操作：16.00秒の検証プロジェクトを末尾ジャンプで16.00へ（末尾ボタンdisabled）、先頭へ戻して1フレーム進め0.03秒。検証動画を読み込み、全4clip IDs・尺16.00・位置0.03が完全一致、素材は未配置、libraryが開いたまま。
- 空だったV2を選び詳細→素材一覧へ戻るでV2保持、試聴停止。V2配置で新クリップがvideoTrackUpperへ、V2行を表示して選択、編集画面へ戻る。V3を選んで同じ素材を配置するとvideoTrackTopへ、Undoで復元。既存動画＋新規WAVの複数読み込みではclip数5・尺16.00・位置16.00が不変、WAVは未配置。ブラウザエラー0。
- 320×650／393×650／430×852／590×393で末尾を含む全5再生操作と時刻表示がviewer-controls内、時刻のscrollWidth超過なし、ページ横超過0。Mac1440×900は従来の再生操作を維持。詳細はvalidation/2.2.38-ui-geometry.json。
- npm test・静的build・Pythonパイプライン・localhost試験成功。Mac ZIPは反映時に確認。元版161ファイルはハッシュ一致。実機Safariの指操作・HDR・長時間使用は未確認。

## 2.2.37 — Macタイトルバー圧縮（2026-10-09）

- Mac幅801px以上のみタイトルバー62→56px、上下padding6pxへ。ロゴ34px・コンテキスト35px・履歴32px・書き出し34px・操作タブのサイズを維持。
- 1440×900／1024×768／1920×1080でheader56px、表示中のタイトル・ロゴ・選択情報・履歴・書き出しは枠内、横超過0。393×650はphone header40pxで変更なし。validation/2.2.37-ui-geometry.json、mac-2.2.37-header.jpg。
- localhostサーバー試験成功。npm test・build・Python動画処理・Mac ZIPは反映前に確認。元のMac版161ファイル変更なし。実機Safari／HDR／長時間操作は未確認。
- iPhoneの読み込みはimportFilesのphoneImport条件で自動配置し、appendMediaは選択映像レイヤー末尾、useAudioは再生ヘッドに配置することをコードで確認。今回は提案のみで挙動変更なし。

## 2.2.36 — タイトルバー圧縮（2026-10-09）

- スマホヘッダー44→40px。履歴ボタン38px、書き出し32→30px、ロゴ17→16px。タイトル文字12px・SVG20px・横幅を維持。Macは変更なし。
- 320×650／393×650／430×852／590×393でheader40px、タイトル・Undo・Redo・書き出しが全て枠内、横超過0。393×650でプレビュー291px／タイムライン229px（前版289／227）。Mac1440×900はheader62px、desktop UI、横超過0。validation/2.2.36-ui-geometry.jsonとiphone-2.2.36-header.jpg。
- AndroidはUAによる拒否なし、phoneLayoutの画面幅／coarse pointerでスマホUIへ。端末書き出しはVideoEncoder・AudioEncoder・Worker・OffscreenCanvas・OPFSを必要とし、Worker内でH.264/AAC対応を個別チェック。Android実機・指操作・実写HDR・長時間編集は未検証。
- localhostサーバー試験成功。npm test・build・Python処理・Mac ZIPは反映前に完了を確認。元のMac版161ファイルは全てハッシュ一致。

## 2.2.35 — iPhoneの整列・余白・高さ配分（2026-10-09）

- 中央4項目のボタン／native selectを同じ28px・align-self centerへ。phone-onlyのdisplay:flexをselectのみblockに戻し、native選択文字のズレを解消。操作段32→30px、下部アクション34→32px、ツール48→46px（ボタン44pxを維持）、合計6pxを編集領域へ戻す。
- ドラッグ比率上限76→84%、標準時のタイムライン最低224→152px。プレビュー優先にも同じ拡大限度を適用。タイムライン優先の224pxは維持。短い画面は比例制限。更新モジュールにcache queryを追加。
- 393×650で境界を実ドラッグしプレビュー289→364px、タイムライン152pxを確認。320×650・393×650・430×852・590×393で中央4項目のy座標と高さ一致、ページ横超過0・下部全7SVGが各ボタン内。横画面は左右分割を維持。validation/2.2.35-ui-geometry.json、iphone-2.2.35-layout.jpgに記録。
- npm test・静的ビルド・Python動画処理パイプライン成功。localhost試験成功。Mac1440×900でdesktop切替・横超過0・スマホツール非表示、ブラウザエラー0。Mac ZIPは反映時に確認。元版161ファイル変更なし。実機Safariのnative selectと指ドラッグは未確認。

## 2.2.34 — Macタブの収まりとiPhoneアイコン（2026-10-09）

- npm test、静的ビルド、Python動画処理パイプライン、localhostサーバー試験が成功。元のMac開発版161ファイルのハッシュ一致。Mac ZIPは反映時に再生成。

- 1440×900で操作グループ高43pxに対しpadding上13／下2px・枠2px・ボタン32pxとなり、下へ3px超過することを再現。ボタン28px・上padding11pxへ修正。選択前後とも枠1pxに揃え、フォーカス枠をoutline-offset -2pxで内側へ収める。カテゴリ文字は8px、非選択グループの減光を解除。
- 1024×768ではボタン31px、800×700では35pxとしてナビゲーション内へ配置。1440／1024／1920の全9タブはグループ底から3px内側。800ではグループがdisplay:contentsのためナビゲーション基準で扱う。1440のBASICをTab→Shift+Tabでキーボードフォーカスし、outline2px・offset-2px・選択aria-pressed true・ナビ内を実操作確認。
- iPhoneは履歴／プレビュー拡大のSVG18→20px、非表示レイヤー見出しのopacity .48→1へ。切替アイコンの斜線・状態色は維持。設定リセットの色を明るくした。レイヤー行高・クリップ位置・編集領域の高さ配分は維持。
- 320×650／393×650／430×852／590×393でページ横超過0、下部ツールの全7SVGと表示中レイヤーSVGがボタン内。下部ツールの高さ46px・最小幅44px。393×650でプレビュー287px／タイムライン225px、430×852で400px／314px、横向きは左右267px高。詳細はvalidation/2.2.34-ui-geometry.json。
- iPhoneのV3表示切替を実際にクリックし、非表示状態・斜線アイコン・見出しopacity1・状態色rgb(223,187,163)を確認。再クリックで復帰。カラー設定は393幅で本文365px、320幅で292pxに収まり、全26項目リセットの行に横超過なし。ブラウザエラー0。
- 競合の公式資料（LumaFusion／Premiere mobile／iMovie／CapCut／Canva／Edits）を調査し、既存PVEとの差分と優先順位をresearch/mobile-timeline-review-2026-10-09.mdに記録。新機能候補は今回未実装。競合実機操作、PVE実機Safari／HDR／長時間編集は未確認。

## 2.2.33 — 対象表示・専用アイコン・範囲別リセット（2026-10-09）

- 目／非表示の目／スピーカー／ミュート／連動／履歴／展開／リセットにアプリ専用SVGを導入。既存のiPhoneツールSVGは維持し、音声連動の絵文字を除去。押下状態・アクセシブル名・非表示／ミュートの色を保持。アイコンは装飾として支援技術から除外。
- 設定見出しに種別・レイヤー番号・素材名を併記し、Macは省略時もtitleで全文を確認可能。設定モード・音量ポイント・レイヤー移動の用語を整理。数値の文字を12pxへ、数値入力に項目名のラベルを付与。
- カラー・位置・音量・フェード・ディレイ等の数値横に項目リセット。カラー／ルックと動き／位置／透明度、音声クリップのまとめて戻す操作を範囲別に表示。音声はミュート／連動／段音量を維持、動きは速度／尺／手ぶれ補正を維持。Undo履歴へ記録。
- Undoが未選択のテキストを最初のテキストへ自動選択していた問題を修正。もともと未選択ならnullを維持。動画・音声のUndo後に設定対象が変わらないことを実操作で確認。
- 1440×900で露出0.02→項目リセット0.00→Undo0.02、対象V1 first.mp4を保持。A1のミュートをON→クリップ音量リセットでポイント0件・ミュートON・映像連動維持→Undoで1件復元し対象A1を保持。
- 393×650でiPhoneへ自動切替、一覧からV1を選択しカラーを開く導線を確認。V1 first.mp4の見出し、26個の項目リセット、プレビュー333px、ページ横超過0px。レイヤー表示切替はキーボードでも状態・目アイコンが切替。実機指操作は未検証。
- スコープ別リセットの自動試験で配置／尺／速度／補正／ミュートの保全を確認。npm test・静的ビルド・Python動画処理・localhostサーバー試験を実施。記録画像はvalidation/mac-2.2.33-controls.jpgとiphone-2.2.33-controls.jpg。実機Safari・HDR・長時間編集は未確認。

## 2.2.32 — 音量ポイントの時間位置と狭い設定画面（2026-10-09）

- 音声エンベロープの左右17px余白と座標内の3px余白で、ポイントと波形がクリップの時間軸より内側へ圧縮されていた。キャンバスをクリップ全幅へ揃え、時間⇔横位置を全幅で変換。選択時も枠幅を1pxに保ち位置を不変にした。
- ポイントを横へずれてつかんだ場合のオフセットも保持。実操作で1.00秒の点を5px横からつかみ上下へ動かしても1.00秒を維持、100px横移動で3.00秒となることを確認。設定メニューの時刻表示で確認。validation/mac-2.2.32-envelope.jpg。
- 800×700の拡張設定パネルでタブが左右各6px、上8pxはみ出すことを再現。本文の実際の左右余白とタブ余白を連動し、上余白とsticky位置を整理。修正後は本文／タブの左右端が一致し、scrollTop700でも上端が一致。
- 1440×900で音声クリップとキャンバスは同じ左端・幅400px。393×650のiPhone画面も左右差0px。8〜1200px幅・0.16〜8秒尺の時間投影と逆変換、上下ドラッグの時刻保持・横移動を自動試験。
- npm test、静的ビルド、Python動画処理パイプライン、localhostサーバー試験が成功。元のMac開発版は編集せず、端末切替版へ適用。実機Safariの指操作・聴感・長時間編集は未確認。

## 2.2.31 — Mac向けUIの段内配置と幅の修正（2026-10-09）

- DesktopでFXのtop0/high25と文字のtop15/high12が同じ段内で10px重なることを再現。52px段を維持してtop2/high23とtop27/high23へ分離。単独ならtop2/high48。文字の削除→FX単独48px、Undo→上下23pxへの切替をUIで確認。
- 0.16秒FXは1300px・26秒の時間軸で期待8pxに対しpaddingで22pxへ拡大していた。Desktopのみpadding0・min-width2px・text-indent10pxで時間軸の幅を保全。映像／音声にもpadding0とtop2pxを適用し、48px／40px高の上下余白を各2pxに統一。
- 1024×768・1440×900・1920×1080で全10段の見出し／レーンの上端差・高さ差は0px。FX・文字・映像3・音声1の6クリップに上下はみ出しなし、期待横位置・幅との差は最大0.008px未満。ページ横はみ出しなし。測定結果はvalidation/mac-2.2.31-geometry.json。
- Colorのスライダーは幅261pxの親へ標準margin2pxが加わり左右位置が2pxずれることを再現。Desktopのcontrol-section rangeのみmargin-inline0で修正。
- Macの設定タブは20pxのスクロールパディングと-20pxのsticky offsetが組で正しく機能。scrollTop900でもタブ上端は設定本文の上端168pxに一致し見切れなし。iPhoneのsticky指定をそのまま移植する変更は不要。
- 修正後の調整rangeは親の左右端との差0px。393×650でiPhoneの混在段76px・クリップtop2/39px・各35px高を維持。ブラウザエラーログ0件。npm test、静的ビルド、Python動画処理、localhostサーバーを通過。Mac ZIPは反映時に再生成。
- 元のMac開発版161ファイルのハッシュ一致。端末切替試験版のDesktopに適用。実機Safariの指操作・長時間編集・全機能の全組合せは未確認。

## 2.2.30 — iPhoneの改善をMac向けUIへ移植（2026-10-09）

- PreviewPlaybackSchedulerを共通モジュールへ分離。端末を問わず映像pending中も音声同期を50ms間隔で継続し、古い世代の完了・エラー・未開始処理を破棄。PhonePlaybackScheduler名は互換exportで維持。
- beginPlaybackの音声／映像窓キャッシュをMacにも適用。pause時破棄・構造変更前のpauseは維持。Macは従来の再生時計・音声ドリフト補正・プレビュー解像度・FPS設定を維持し、iPhoneの低解像度／低FPS予算は移植しない。
- 時間ラベルの端クランプとつかんだ位置を保つドラッグを共通化。停止中のタイムラインスクロールにもラベル位置を更新。短い映像／音声／FX／文字の両端領域を最大25%に制限し中央に移動領域を残す。
- ローカル1440×900で既存の合成3クリップを復元し、Mac UIで再生0.23秒、先頭復帰、再生ヘッド100pxドラッグ→2.00秒、再開2.22秒、終端16秒へシーク・全DOM video停止を確認。先頭／終端の時間ラベルは表示範囲内。393×650でphoneへ切替を確認。元のMac開発版は編集せず、端末切替版のdesktopに反映。
- npm test・静的ビルド・Python動画処理・localhostサーバー試験を通過。Mac ZIPは反映時に再生成。元のMac開発版161ファイルのハッシュ一致。実機Safariの聴感・長時間編集・重い素材は未確認。初回の編集途中に構文エラーを検出し修正済み。現在ソースで静的検査とUI再読み込みを実施。

## 2.2.29 — iPhoneの操作欄と表示の微調整（2026-10-08）

- 下部ツール7個のアイコンを同じ20px・線幅1.7のSVGへ統一。装飾をaria-hiddenにし、ボタン名は日本語のテキストで保持。
- タイムライン操作欄36→32px、選択情報22→20px、クリップ操作36→34px。合計8pxを編集領域へ配分。下部ツール48px・各ボタン最低幅44pxは保持。プレビュー左右余白5→2px。
- 時刻を正立・等幅数字、段名を読みやすい太さへ調整。画面配分の選択欄、設定の見出し・選択タブ、無効状態・押下状態の色を整理。レイヤー寸法・クリップ配置計算・書き出し処理は変更なし。
- ローカルブラウザで素材3件を追加し、写真をV1からV3へ移動、カラー設定と編集復帰、画面配分の切替を確認。393×650・320×568・568×320で横はみ出しなし、表示中のV3/V1見出しと映像レーンの上端・高さ一致。320px幅でもツール7個が各44pxで収まる。1440×900はdesktopへ切替、phoneツール非表示。エラーログ0件。
- npm test、静的ビルド、Python動画処理、localhostサーバー試験を通過。Mac ZIP生成も反映時に実行。元のMac開発版161ファイルのハッシュ一致。実機Safariのタップ感・ブラウザバー伸縮・キーボードは未確認。

## 2.2.28 — iPhoneプレビューの音声優先・負荷調整（2026-10-08）

- 映像同期がpending中も音声同期を50ms間隔で続けるPhonePlaybackSchedulerを追加。古い世代の未開始同期とエラーを破棄し、古い完了が新しい同期のpendingを解除しないことをテスト。
- iPhoneの再生開始時のみAudioPreviewの音声／映像窓を計算し、再生中は再利用。pause／export解放で破棄し、編集後の再生開始で再構築。音量の自動化や音声のシーク方式は維持。
- PhonePreviewBudgetは通常24fps・長辺最大960px。描画CPU時間が予算の65%を3回連続で超えた場合だけ20fps/720px、15fps/540pxへ変更。60回連続で軽い描画なら1段戻す。単発の遅延では変更しない。停止時は即時再描画し通常解像度へ戻る。DOM時間表示は再生中10回/秒。非表示になったiPhoneは再生を停止。
- 複数レイヤーとトランジションの描画にも同じ解像度予算を渡す。明示的な書き出しサイズは予算の対象外。テストで4K 2160×3840保持、Macプレビュー1280×720保持、停止時960px復帰を確認。
- ローカルブラウザ393×650で8秒の合成プロジェクトを先頭から終端へ再生。再度先頭へ戻して再生、3秒付近へシーク、複数レイヤー区間の再生／停止／再開を操作。時刻3.36秒で映像要素readyState4・paused=false、source時刻2.519秒。停止後はすべてのDOM videoがpaused=true、play表示は再生。エラーログ0件。
- 1440×900はdesktopのまま、先頭再生0.23秒・停止を操作確認。元のMac開発版161ファイルはハッシュ一致。
- 合成300クリップ・1000回の配置計算のみのローカル計測：非キャッシュ50.05ms／キャッシュ1.22ms。これは実機の再生速度や聴感の改善倍率ではない。
- npm test（新規scheduler・負荷制御・解像度テストを含む）、静的ビルド、Python動画処理、localhostサーバー、Mac ZIP生成を実施。実機Safariの聴感・HDR/4K・長時間編集・背景移行は未確認。実機での途切れ解消や実速度の改善は未保証。

## 2.2.27 — iPhone表示の横断点検（2026-10-08）

- 320×568、393×650、568×320のブラウザ表示で点検。10段の見出しとレーンの上端差／高さ差はいずれも0px。FX・文字・映像・音声7クリップの上下はみ出しなし。横位置の計算との差は最大0.008px未満。
- 横向き568×320はプレビュー列264px内へ従来の再生バーが入り切らないため、時刻14px行と操作38px行へ分離。操作列幅162px・列内左右余白51px以上、時刻と操作の縦重なりなし。タイムラインの6ボタン＋画面配分は列内に収まる。
- 短いFXの幅22pxに両端各24pxが重なる問題を発見。トリム領域を最大25%に制限し、各5px・中央15pxを確保。中央ドラッグで配置時刻移動とUndoを操作確認。クリップ名のleftとmarginの二重オフセットも解消。
- overlay-head smallのdesktop display:block!importantがphoneを上書きし、OVERLAY補助ラベルが3pxへ潰れることを発見。phoneのみ非表示にして表示ボタン／段名を保全。desktopは52pxの段と8.5pxの補助ラベルを保持。
- カラー（3-way、カーブを含む）、基本（トランジション、リフレーム等）、モーション詳細、ルック、文字（フォント・縁取り・影・背景・配置詳細を展開）、音声（選択前後、4段、音量点、フェード）、素材一覧・検索・フィルター、レイヤー一覧・移動先、FX詳細、解析、書き出し設定を操作し、320px幅を超える設定部品がないことを確認。
- 音声パネルはscrollTop2059/scrollHeight2254/clientHeight195で末尾ボタンが486〜530pxに収まり、画面内で到達可能。FX／解析の見出しがsyncで内部キーへ戻る問題を修正。
- geometry.jsonに3サイズの座標測定を保存。今回の検証は表示・配置が中心で、各設定の全組合せ、完成MP4書き出し、実機Safariの指操作・キーボード・長時間編集は未実施。
- npm test、静的ビルド、Python動画処理、localhostサーバー、Mac ZIP生成を実施。元のMac開発版161ファイルのハッシュ一致。

## 2.2.26 — iPhoneのFX・テキスト段内配置（2026-10-08）

- 40pxの段へボタン共通min-height:44pxとtext top:15pxが適用され、テキストが19pxはみ出す問題をブラウザで再現。
- iPhone専用でクリップを段内の2px余白・36px高に変更。FXとテキストの混在時はその段と見出しのみ76pxへ拡張し、35pxの上下2行を分離。段のoverflowで隠す処理は追加していない。
- 393×650／320×650で混在クリップの上端2／39px、下端余白39／2px、見出しとの縦位置差0pxを確認。段移動操作後は双方40px／クリップ36pxへ戻ること、ドラッグで混在段へ戻した後のtransform解除と段内配置を確認。
- 動画48px/段64px、音声42px/段48pxで段内に収まることを確認。1440×900はdesktop、オーバーレイ3段は従来の52px。元のMac開発版161ファイルのハッシュ一致。
- npm test、静的ビルド、Python動画処理、localhostサーバー、Mac ZIP生成を実施。実機Safariでの指操作は未確認。

## 2.2.25 — プレビュー設定のスマホ向け説明（2026-10-08）

- その他の下部へスクロールしてプレビュー設定と端末対応状況を開き、閉じる操作で編集へ戻れることを幅320×568で確認。
- iPhoneの描画上限24fpsに対し、共通の設定に60fps／Mac向け説明が残っていた。スマホでは実際の上限を表示し、選択肢をメモリ解放タイミングとして説明する。「高画質」は「再開を優先」と表示。Macの表示・動作は維持。
- 端末対応状況はAPI対応と素材ごとの追加確認を区別して表示していた。実機Safariの確認は未実施。

## 2.2.24 — 再生位置・時間表示・設定導線の再点検（2026-10-08）

- 全10段（映像3、音声4、文字FX3）の左見出しと段本体について、高さ・Y位置の差が0pxであることを393×650ブラウザで確認。縦391pxスクロール後もA2の差は0px。クリップの横位置と指定割合の誤差は最大約0.0051px。
- 先頭の時刻ラベルが左のレイヤー欄へ36pxはみ出していた。ラベルだけを表示範囲に収め、三角印と再生ヘッドの実位置は維持する。ドラッグ開始時のつかんだ位置を保持し、押した瞬間のシークを防ぐ。左右端・中間・横スクロール後のラベル補正はtimeline-time.testで確認。
- プレビューと再生ヘッドの00:00:00.32、スライダー表示0.32秒の一致を再生操作で確認。終端でスライダーの丸めと他の時間表示が異なることを発見し、百分の一秒の切り捨てに統一、スライダーも0.01秒刻みに変更。
- その他を用途別に分類、画面比率を「動画全体」と明記。幅320pxでその他→モーションを操作し、見出しの連動と設定の横幅292px=scrollWidthを確認。範囲編集の見出しが別タブ名になる問題も修正。
- 修正後、終端の時刻00:00:08.00とスライダー8.00秒が一致、ラベル右端393px=表示範囲右端393pxを確認。先頭のラベルをクリックしても0秒を保持。ラベルのボタン共通アニメーションを無効化して遅れを除去。
- 実機Safariでの指ドラッグ・縦横向き・動的ブラウザ領域は未確認。

## 2.2.23 — iPhone補助編集の対象明示・原音導線・出力比率保護（2026-10-08）

- タイムラインに選択対象・段番号と横移動の案内、設定見出しに段番号・素材名を追加。映像設定の4タブを日本語にし、切替に合わせ見出しも変更。素材のIN/OUTは「素材の開始／終了」と明記。
- 分離済み原音の映像側では音量操作を隠し、sourceClipに対応する音声を選択するボタンを表示。ブラウザでV1 second.mp4からA2 second.mp4への移動を確認。対応音声がなければボタンを無効化して説明する。
- 基本音量・ポイント・段の音量が重なることを案内。モーションの4つの詳細セクションを折りたたみ、元の操作・IDを保持。ブラウザで閉じた詳細と「モーション」見出しを確認。
- iPhone書き出しの初期比率はEDIT。9:16編集に1080×1920を表示することを確認。16:9へ変更し未確認で開始した場合は設定画面に留まり、確認案内が表示されることを操作確認。Macの初期設定／比率選択は変更しない。
- iPhoneレイアウトへ移行時にMac接続失敗の案内を消去。実機Safariでの指操作・聴感・長時間編集は未確認。この版では完成MP4の実操作書き出しは実施していない。

## 2.2.22 — V3見出しの見切れ修正（2026-10-08）

- 左端TIME固定見出しの高さをスマホの目盛り28pxへ統一し、paddingを除去。デスクトップ用の高さ＋余白が最上段を覆う問題を修正。
- 映像／文字段名の最小高さ44pxを解除し、表示ボタンと段名が各段内へ収まるよう調整。
- 393×650ブラウザで素材をV3へ移動して確認。V3段の上端431px／下端495pxに対して、表示ボタン441.5〜465.5px、段名465.5〜483.5pxが収まり、TIMEは28px・余白0となった。実機Safariは未確認。

## 2.2.21 — スマホ表示の見切れ修正（2026-10-08）

- 設定タブに残っていたデスクトップ用の負の余白とsticky位置をスマホでは解除。4タブを画面内へ収め、背景を不透明にした。タブ切替後のスクロールは0へ戻す。
- 393×650と320×568のブラウザでカラー／モーションの切替を操作。カラーの横幅は393px画面で365px、320px画面で292pxとなり、scrollWidthとclientWidthが一致。スクロール後のタブ切替でscrollTop=0を確認。カラー最下部の処理プレビューボタンへ到達できることも確認。
- 時刻表示の中央を隠していた三角印を下へ移動。クリップ名と尺は両端ハンドルを避けて省略表示。速度入力と狭い画面の再生／タイムラインツールの寸法を調整。レイヤー見出しは独立スクロールせずクリップ段へ追従する。
- iPhone Safari実機での動的アドレスバー、キーボード表示、横向き操作は未確認。

## 2.2.20 — 音量ポイントの操作分離・素早い横移動・レイヤー切替（2026-10-08）

- 音声エンベロープのポイントと選択中の音量線では、タイムラインのタッチ処理を通さず音量編集へ渡す。タッチのポイント判定を14pxへ拡大。選択済みクリップの横方向操作は7pxで移動開始し、縦方向はスクロール。メニューの保持時間は380ms。
- phone-touch.testで即時横移動、選択済みクリップの縦スクロール、エンベロープへの委譲時にスクロールしないことを検証。従来の長押し、段移動、ピンチ、キャンセルも維持。
- 393×650ブラウザで音量線へポイントを追加し、下へドラッグして-96dB表示を確認。縦スクロール81px・横0pxは変化しなかった。これはマウス入力の操作確認であり、実機タッチは未確認。
- タイムライン左端に映像／文字の表示切替と音声の消音切替を常設。A2の消音／解除、V1の非表示／表示を操作して状態変更を確認。
- 先頭ボタンで0秒と横スクロール0へ戻る。先頭でクリップ左端、再生ヘッド、時刻ハンドル中央がすべて画面X=44pxで一致することを確認。モバイルのクリップ左右余白を除き、短いクリップが指定尺より広がる原因を修正。
- npm test、Python動画処理一式、認証・Range・素材ストリーミングなどのサーバー試験を通過。元Mac版161ファイルはSHA-256照合で変更0件。
- 実機iPhone Safariでの指入力・音量の聴感は未確認。

## 2.2.19 — 長押し・スワイプ・段またぎドラッグ・鮮明な調整プレビュー（2026-10-08）

- iPhoneタイムラインに単一のタッチ操作処理を追加。短いスワイプは縦横スクロール、クリップを460ms保持すると操作メニュー、そのまま移動すると時刻／段のドラッグへ切り替える。指を離したタップは既存の選択・シークへ渡す。移動中の端スクロール、キャンセル時のUndo履歴復旧、2本指ズームを維持する。
- 長押しメニューは分割・設定・コピー・切り取り・複製・削除・段ドラッグへ対応。設定を開く操作はiPhoneの設定パネルも開く。空の移動先段はドラッグ中だけ表示し、同じ種類の映像／音声／文字・FXトラック内を移動できる。映像を音声段へ変換する移動は行わない。
- phone-touch.testでスワイプとドラッグの排他、長押し、タップ、キャンセル、移動モード、2本指ズームを確認。ブラウザ画面でクリップメニューとV3→V2の段またぎドラッグを操作確認。ブラウザ入力はマウスであり、実機Safariの指入力は未検証。
- モバイルの段高さに合わない52px／44px固定値を避け、ドラッグ表示は実際の移動先段の位置を使う。ドロップ後は従来の保存・履歴・リンク音声同期を利用する。
- カラー・ルック・テキスト・モーションなどの調整パネルを画面高さ42%へ縮小。背景のぼかしと暗幕を解除し、カラー・テキスト等ではプレビューも操作可能とした。393×650でプレビュー高さ295px（前版248px）、backdrop-filter:noneを確認。カラーの説明行も詰め、調整項目へ早く到達できるようにした。
- テキストの改行入力、追加・複製・削除、F/T1→F/T2変更とプレビュー反映をブラウザで確認。無効な開始／終了を拒否した際に入力欄も現在の値へ戻す処理を追加した。文字プレビューの直接操作を妨げていたinert指定を調整した。
- 単一映像トラックで全尺が連続し、透明度・フェード・遷移・文字・FX合成がない場合は、GPU処理済みCanvasを直接WebCodecsへ渡す。カラー・画面変換・モーションはGPUで維持し、別Canvasへのフルフレームコピーを省く。条件を外れたプロジェクトは既存の合成経路を使う。
- ローカル検証ページで実際のworkerを実行し、directCanvas:true、verified:true、1秒30フレームのMP4生成とブラウザ表示を確認した。処理時間0.182秒はMacブラウザ上の160×90テスト素材の結果であり、実機の速度改善率を表さない。検証専用HTMLは公開前に削除した。
- npm test、Python動画処理試験、サーバー試験を通過。長押し・スワイプ・端スクロールの実機Safariの体感、実写4K/HDR長尺の速度・温度・メモリは未確認。

## 2.2.18 — 下部UI圧縮・安定した設定スクロール・レイヤー復帰（2026-10-08）

- iPhone下部ツールを60→48px、クリップ操作を44→36px、再生位置を30→24px、再生操作を44→38pxへ圧縮。393×650のブラウザで実寸を確認し、プレビューとタイムラインの表示領域へ合計32pxを戻した。表示したプレビュー領域は248px、タイムラインのレーン領域は163pxだった。
- タブ内の入力・空白をクリックした際、スタイル用のbody[data-phone-panel]まで操作ボタンとして判定して設定画面を開き直す問題を修正。操作ボタンの祖先だけを判定し、入力・戻るボタンがbodyへ誤判定されない回帰試験を追加した。
- レイヤー表示は状態が変化した時だけ描き直し、シート内のpointerup時には描き直さない。タップ途中のボタン交換を防ぐ。映像／音声／文字タブ、現在段、移動先、各段の＋素材を中心に画面を簡略化した。
- 段移動が成功すると自動で編集画面へ戻り、結果を表示。素材追加も指定段への配置後に編集へ戻る。「完了」は「編集へ戻る」へ改名し、非表示になった起点ボタンへフォーカスを戻さない。
- 393×650のブラウザでfirst.mp4のV2→V3移動、自動復帰、戻るボタンによる復帰、V2の＋素材→ライブラリ→photo.pngのV2配置→自動復帰を操作確認した。V3の既存クリップとの衝突は明示メッセージを表示し、写真をV2に保持した。
- モーションの外側は固定し、内容だけをスクロールする。音声パネルは全内容を一つの外側スクロールに統一。ブラウザでモーションを411pxスクロール後、不透明度の数値入力をクリックしても411pxを維持、外側スクロールは0だった。
- 書き出しの進捗画面にアプリ・タブを閉じない／移動しない／画面をロックしない注意を表示。実際の1080p・8秒書き出し中に表示を確認し、MP4完成と編集への復帰も確認した。
- npm test、Python動画処理試験、認証・Range・素材ストリーミングなどのサーバー試験を通過。元Mac版161ファイルはSHA-256照合で変更0件。
- iPhone実機Safariのタッチ・キーボード・バウンススクロールは未確認。ブラウザのiPhone相当画面サイズでの確認である。

## 2.2.17 — iPhoneのレイヤー操作・書き出し復帰・連続デコード（2026-10-08）

- 専用のレイヤー編集画面に映像3段、音声4段、文字・FX3段を分けて表示。重なり順と音声の同時再生を説明し、各段の素材一覧、配置先指定、時刻を保った段移動、先頭／再生位置への整列を実装した。
- 393×650／393×852のブラウザで映像をV2、音声をA2へ移動し、V3の追加ボタンから素材ライブラリを開いてV3へ配置できることとUndoを確認。段の衝突拒否・時刻保持・リンク音声同期・文字移動は自動試験を通過した。
- 書き出し時にAudioContextを閉じた後、接続済みの同じ音声要素を再利用していた問題を修正。音声要素を再作成し、Safariのinterrupted状態も再生操作から復帰させ、完成動画の試聴音声は閉じる時に停止する。
- ローカルブラウザで2回書き出し後に編集画面へ戻り、音声を基準とする再生時計が8秒の終端まで進むことを確認した。実機Safariでの聴感確認は未実施。
- 端末書き出しは映像の連続デコード、音声のPCM窓の再利用、ハードウェア処理の優先指定へ変更。書き出し開始時はプレビューのデコーダー／音声を解放する。GPU合成を維持し、対応しない端末では従来の対応経路を選ぶ。
- 完成確認は全パケットのフレーム数・時刻・尺と先頭／中央／末尾の復号へ変更した。全尺の再復号は通常の書き出しから外した。
- 8秒の合成素材（低解像度の動画2本、画像、文字、440Hzと660Hz音声）で端末処理経路を操作。180×320・30fpsは0.7秒、1920×1080・30fpsは0.9秒と完了画面に表示された。これはMacのブラウザで低解像度素材を処理した結果であり、iPhoneや4K素材の速度保証ではない。
- 保存MP4はH.264／AAC、映像8秒240フレーム。FFmpegで全240フレームを復号し、最初の90フレームがすべて変化すること、440Hzと660Hzの音声が混合されていることを確認した。
- npm test、Python動画処理試験、サーバー試験を通過。元のMac開発フォルダは161ファイルのSHA-256照合で変更0件。
- iPhone実機のSafariでの音声、長尺4K／HDRの実時間・温度・メモリ消費は未確認。ハードウェア指定はブラウザへの優先希望であり、CPUの全コア利用を強制するものではない。

## 2.2.7 — トランジション中の連続再生（2026-09-28）

- 前側クリップを最終フレームへ固定していた処理を改め、編集点以降に残る元素材をトランジション尺へ割り当てた。元素材末尾で後続フレームがない場合だけ最終フレームを保持する。
- ブラウザプレビュー、端末内MP4、Mac FFmpegの各経路へ同じ判定を実装し、動くマーカーを使った回帰試験で前側映像が遷移中も進むことを確認した。
- `IMG_7917.mov` と `IMG_7697.MP4` を使い、ディゾルブ、スライド、ラインワイプ、サークルワイプを30fps処理プレビューと1080×1920・60fps最終書き出しで検証した。各効果の0.2／0.4／0.6秒地点、計24フレームの理論合成との差は8bit RGB平均で1.009〜6.504階調だった。黒フレーム、4フレーム以上の停滞、境界音声の無音欠落はなかった。
- iPhone 16 Pro Safari、Mac Safari、実写4K/HDRでの目視比較は未実施。

## 2.2.6 — トランジション／書き出し完了確認（2026-09-28）

- Canva公式の動画トランジションを確認し、主要4種（ディゾルブ、スライド、ラインワイプ、サークルワイプ）を同一レイヤーで接するクリップ間へ実装した。Match & Moveは要素単位の対応付けが必要なため、平面化された動画クリップへ名前だけを流用していない。
- 設定の正規化・保存復元・隣接判定・滑らかな補間・Canvas合成・端末書き出し経路をJavaScriptで検証した。Mac FFmpegでは赤→青のディゾルブ中間画素、1.600秒の尺、AAC音声の連続性、4種のフィルタ対応を確認した。
- 実写の `IMG_7917.mov` と `IMG_7697.MP4`（iPhone 16 Pro、HEVC、約60fps VFR、回転メタデータ付き）を交互に5本並べ、4種類を連続適用した。540×960・30fps処理プレビューと1080×1920・60fps最終書き出しをそれぞれカット版と比較し、各効果の0.2／0.4／0.6秒地点、計24フレームを画素検査した。理論合成との差は8bit RGB平均で0.174〜3.374階調、黒フレーム、4フレーム以上の停滞、境界音声の無音欠落はなかった。
- 検査中に、ラインワイプの左右／下方向がCSSプレビューで別の辺を基準にしていた問題、Mac書き出しだけ直線補間だった問題、0.8秒刻みのフレーム丸めで開始値が極小の負数になり得る問題を修正した。全経路をsmoothstep補間へ統一し、負の丸め誤差を0へ正規化した。
- 書き出し完了画面の閉じるボタンは確認画面を経由し、キャンセルすると完成MP4のプレビューへ戻れることを自動試験した。
- `npm test`、`npm run build`、Python動画処理一式を通過した。iPhone 16 Pro Safari、Mac Safari、実写4K/HDRでの各トランジションの目視比較は未実施。

## Validation — 2026-09-27

### 2.2.5 — 縦スクロール／レーン整列／英語UI

- 縦スクロール値を後から書き換えないこと、レイヤー見出しが同じスクロール量へ追従することを自動テストした。
- F/T、V、A、マーカーレーンの高さをタイムライン本体と左側表示で共通化した。
- プレビューのサイズ調整枠が通常時に消え、ホバーまたは直接操作中だけ表示されることを確認した。
- `index.html`の日本語テキスト、ツールチップ、アクセシビリティ名が英語へ変換できることを自動検査した。
- Chrome実画面へ縦長の赤い動画を配置して0.30×へ縮小し、左右画素が黒、中央画素が赤、待機中のサイズガイドが非表示であることを確認した。
- Mac書き出し用の空間変換を0.1〜3×に拡張し、縦素材を16:9へ配置した合成テストで左右の黒余白と中央の映像を画素検査した。
- ブラウザ書き出しのHDR停止判定を除去し、PQ / HLG検出とSDRキャンバス経由を自動検査した。生成HLG/HEVC素材はChromeへ正常に読み込めた。現在の検証MacのFFmpegには`zscale`がないため、Mac実動画のHDR→SDR変換とiPhone 16 Pro Safariの受け入れ検証は未実施。
- `npm test`、`npm run build`、Mac動画処理テスト一式を実行。VFR、240fps、ProRes、映像3層・音声4層、音声境界、テロップ／FXのみ、YouTube構成、0.05〜20×速度、Maximumスローを含めて通過した。

### 2.2.4 — UI統一／ヘルプ／プレビュー直接操作

- 1440×900と1280×800のChromeで、素材・プレビュー・設定ヘッダー、ワークスペース、タイムライン、空状態を目視確認した。
- 選択枠と右下のサイズ変更ハンドルがプレビュー映像を過度に覆わず、中央吸着ガイドと同時表示できることを確認した。
- ヘルプの作業手順、画面領域、直接操作、分類済みショートカットが日本語・英語で表示されることを確認した。
- F/Tレーンは52pxの完全な行として表示され、途中位置への縦スクロールがレーン境界へ吸着することを確認した。
- JavaScript全試験、静的ビルド、Python動画処理14本、ローカルサーバー、Macパッケージ生成を通過した。iPhone 16 Pro Safari実機は未確認。

### 2.2.3 — 手ぶれ補正プレビュー／テロッププリセット

- ブラウザ版の通常プレビューへ、端末書き出しと同じ72px解析、毎秒18サンプル、複数領域の平行移動・回転推定、軌跡平滑化、適応拡大を適用した。WebGL側は書き出しCanvasの変換を逆変換した座標で描画する。
- `IMG_7917.mov`をChromeへ読み込み、NATURALの解析完了と「手ぶれ補正プレビュー適用中」の表示、補正済みフレームの描画、JavaScript例外0件を確認した。実写の補正品質比較とiPhone Safariは未確認。
- 13種類すべてのテロッププリセットを共通Canvas描画で一覧化して目視確認した。位置・サイズ・フォントを維持する現在の操作仕様に合わせ、名称を装飾の見た目へ統一し、各ボタンへ見本文字と具体的な装飾説明を追加した。
- JavaScript全試験、静的ビルド検査、Pythonのcapabilities/images/layers/clip-boundary/multitrack/prores/reliability/validate_pipeline/validate_formats/creative/youtube/program-workflow/overlay-only、Macエンジンのサーバー試験を通過した。
- Mac FFmpegの`vid.stab`は別解析器のため、通常のブラウザプレビューとは一致を保証しない。Mac書き出しとの確認には同じFFmpeg経路を使う「処理プレビューを生成」を使用する。

### 2.2.2 — 3-wayカラーバランス

- Capture One公式資料を基に、シャドウ・中間調・ハイライトへ色相、彩度、明度を独立設定する操作を追加した。輝度マスクは領域間を滑らかに重ね、ハイライト側も緩やかにロールオフする。
- Chromeで3つのホイール表示、ホイール操作、数値・スライダー同期、個別／全体リセット、WebGL初期化を確認した。JavaScript例外はなかった。
- JavaScriptとMac FFmpeg用PythonのRGB計算を暗部・中間調・明部で比較し、同一結果を確認した。実写素材、HDR、iPhone Safariでの見え方は未確認。

### 2.2.2 — プレビュー直接操作・テロップ整理・音声ディレイ

- Chromeでプレビュー上の動画をクリックし、対応するタイムライン素材と `VIDEO · BASIC` が選択されること、画面上のドラッグ移動と右下ハンドルによる拡大縮小を確認した。JavaScript例外はなかった。
- 標準を装飾なしとした13種類のテロップテンプレートを実描画し、重複した見た目がないことを目視確認した。日本語Webフォント6種類を追加した。
- ブラウザ書き出しの連続PCM処理とMac FFmpeg書き出しの両方で、ディレイ有効時の全尺デコードを確認した。300テロップ、100 FXの上限と保存・復元を自動テストした。
- `npm test`、`npm run build`、Python動画処理、3映像／4音声トラック試験を通過した。iPhone Safari、長尺・多素材、実機スピーカーでのディレイ音質は未確認。

## Validation — 2026-09-25

### 2.2.1 — キーボード編集

- 先頭／末尾、前後の編集点、再生ヘッドまでのリップルトリム、タイムライン倍率、吸着切替、複数選択の1フレーム移動を追加した。
- 編集点の収集、60fps単位の複数項目移動、同一トラックのリップルトリムをユニットテストで確認した。
- Chromeで実キー操作し、0秒／8秒への移動、前後の編集点、吸着OFF、150%ズーム、1フレーム移動、3秒地点へのリップルトリムを確認した。JavaScript例外はなかった。Safari実機のHome／EndおよびOptionキー操作は未検証。

### 2.2.0 — プロジェクト専用フォルダ／連続クリップ境界

- ChromeのFile System Access APIを模した自動試験で、専用フォルダ名、`Project.pve`と自動保存、元素材のストリームコピー、相対パスからの復元、最近使ったプロジェクトを確認した。
- Chromeで音声付きH.264動画2本をV1へ連続配置して実再生した。切替前後の連続スクリーンショット3枚はいずれも映像があり、黒フレームはなかった。音声要素の操作は再生2回・シーク3回で、連続した時刻補正は発生しなかった。
- ブラウザ書き出しのPCM試験で、任意の0.973秒地点をまたぐ440Hz／660Hz素材に無音欠落がないことを確認した。Mac FFmpeg書き出しでも赤から青への映像切替、全尺デコード、境界音声の連続性を確認した。
- Safariは専用フォルダAPIがないためブラウザ内保存を使用する。Safari実機での長時間再開、iPhone 16 Pro、実写HDR、長尺・多素材の切替負荷は未確認。

### 2.1.5 — タイムライン行の位置合わせ

- Chrome 1596×965でV1〜V3のラベル行と素材行の上端・下端を実座標で比較し、修正前の12px差が修正後は全行0pxになったことを確認した。
- FX／テキスト3行の古い下余白を除去し、タイムライン内容とラベル列を492pxへ統一した。
- 縦スクロール後もV1〜V3の座標差が全行0pxであることを確認した。`npm test`、`npm run build`、Python動画処理13試験、Mac版ZIP生成を通過した。

### 2.1.4 — UI整合性・英語表示・初期導線

- Chrome 1440×1000で初期画面、テロップ追加、FX選択、英語切替、ヘルプを操作し、JavaScript例外なしを確認した。静的サーバーではMacエンジン探索用`/api/health`が404になるが、ブラウザ版の想定動作である。
- テロップ追加後は00:00:00.08へ移動して内容が表示され、設定欄は5つの折りたたみグループとなる。FX選択時はテロップ選択が解除され、左上の対象表示とタイムライン選択が一致した。
- 英語表示でプリセット説明、ヘルプ、ショートカットを確認し、部分翻訳による日英混在がないこと、フォント名を変換しないことを自動テストした。
- 新規プロジェクトの標準書き出しがYouTubeであること、タイムライン側の重複Undo／Redoが非表示であることを確認した。
- `npm test`、`npm run build`、Python動画処理13試験を通過した。Mac実機・iPhone Safariでの操作は未確認。

### 全リセット操作（未公開の作業版）

- 検証用動画とテロップを配置し、確認画面でキャンセルすると編集が残ることをブラウザで確認した。
- 確認画面に `.project` の保存リンクがあることを確認した。検証用ブラウザではダウンロード完了イベントが得られず、実ファイルの保存完了は未確認。
- リセット後は素材0件、タイムライン0件、編集履歴なし、端末内の保持素材0件となり、再読み込み後も空の状態を維持した。
- `npm test`、`npm run build`、Python動画処理13試験を通過した。Mac実機・iPhone Safariでの操作は未確認。

## 2.1.3 — サイズアニメーション・音量カーブ・全リセット

- サイズポイントの滑らかな補間、Motion変換、属性コピーとプロジェクト保存／復元を自動テスト
- 独立音声とBGMの音量ポイントを実FFmpegで書き出し、低→高→低の実波形を比較。H.264/AACの全尺デコードを確認
- サイズキーフレーム付きのレイヤー合成書き出しを実行し、全尺デコードを確認
- 全リセットの確認画面、保存導線、素材／履歴消去、再読み込み後の空状態をブラウザで確認
- `npm test`、`npm run build`、Python動画処理テスト一式、ローカルHTTPサーバーテスト、Mac ZIP生成を実行
- iPhone 16 Pro Safariと第三者端末での受け入れ確認は未実施

## 2.1.2 — タイムライン／プレビュー同期

- 3～9秒の合成動画は1.99秒と10秒で黒、4.02秒で対応する映像をプレビュー表示した。
- 9～12秒のテロップは10秒で表示・12.49秒で非表示、12～14秒のFXは12.98秒で表示・14.51秒で非表示となることを画面操作で確認した。
- 同じ検証プロジェクトのブラウザ書き出しで、ユーザーが黒画面→合成動画→黒背景テロップ→白いFXの14秒間の順序を確認した。実写素材、全種類のFX、iPhone Safariでの一致は未確認。
- 動画の空白区間への移動でデコーダを停止し、素材の最終フレームを表示し続けない回帰テストを追加した。Motionの1×復帰もテストした。

## 2.1.1 — 連続速度スライダー

- Motionの対数スライダー全域（0.05〜20×）、1×中央点、単調性と任意小数速度のマッピングを自動テスト
- スライダーと速度数値欄の同期・Undo履歴接続を確認
- 実機公開後の操作確認を含め、`npm test`、静的ビルド、Python動画処理、Pages公開を再確認

## 2.1.0 — 任意速度・動き補正実験

速度と速度ランプの任意小数入力（0.05〜20×）を追加し、1.2375×の値がモデル保存とMac FFmpeg書き出しで保たれる回帰テストを追加しました。MaximumスローとAGGRESSIVE手ぶれ補正も公開版に含みます。`npm test`、静的ビルド、Python動画処理一式、ローカルHTTP配信、Mac ZIP生成を確認しています。実写比較はこれからです。AIモデルによる補間、M2の画質・速度、実写手ぶれ補正は未検証です。

## 2.0.8 — スロー再生・手ぶれ補正の強化

- `npm test` と静的ビルド検査を通過
- `tests/validate_pipeline.py`：UMH動き補償を使うスロー書き出し、尺、全フレームデコードを確認
- 解析フレーム数、UMH設定、vid.stab解析間隔の回帰確認を通過
- Mac FFmpegにvid.stabがないため、手ぶれ補正の実写比較は未実施。GitHub Actionsで動画処理全体を検証

## 2.0.7 — 動画末尾の外へのテキスト／FX配置と動画なし書き出し

- JavaScriptテスト一式（同梱Node.js）通過。動画なしプロジェクトの出力尺・フレーム数の回帰テストを追加
- 静的ビルド検査通過
- `tests/overlay-only.test.py`：黒背景、ラスターテロップ、FX、H.264/AAC、全尺デコードを確認
- iPhone Safari実機での受け入れ検証は未実施

## 2.0.6 — 可変ポイント・滑らかトーンカーブ

- Mac Chromeでポイントの追加、上下左右移動、右クリック削除、削除後の原状復帰を実操作確認
- 曲線操作前後の映像プレビュー画像を比較し、GPU反映を確認
- JavaScriptとMac FFmpegで任意位置ポイントの補間結果が一致することを確認
- 旧5点カーブの読み込み、最大16点制限、保存復元、カーブLUTを自動試験
- iPhone 16 Pro Safariと実写HDR素材の受け入れ試験は未実施

## 2.0.5 — iPhone相当カラー調整とトーンカーブ

- 全JavaScriptテスト、静的ビルド検査を通過
- Mac Chromeで20個のカラー項目表示、GPU初期化、トーンカーブの実ドラッグ更新を確認
- ブラウザとMac FFmpegのRGB変換を同じ入力値で比較し一致を確認
- 新しいカラー、カーブ、精細度、ノイズ除去を含むH.264/AAC MP4をFFmpegで生成し、全フレームデコードを確認
- Python動画処理テスト（H.264、ProRes、レイヤー、音声、テロップ、FX、静止画、YouTube）を通過
- iPhone 16 Pro Safariと実写HDR素材の受け入れ試験は未実施

## 2.0.4 — 詳細書き出し設定

- Mac ChromeでYouTube 4K・59.94fps・映像60Mbps・音声320kbps・任意ファイル名の連動を確認
- 3840×2160、7,193フレーム、推定容量約905MBの事前表示を確認
- ブラウザの明示ビットレート計算とMac FFmpegのH.264/AAC引数を検証
- JavaScript全テスト、YouTube、ProRes、ネイティブ動画・多重音声テスト通過

## 2.0.3 — AUDIO素材削除とヘルプ

- Mac ChromeでAUDIO LIBRARYの音声素材削除、確認画面、参照クリップ削除を確認
- 上部ヘルプを開き、5分野の操作ガイドと18ショートカットの表示を確認
- JavaScript全テスト、静的ビルド、音声多重化・YouTube・ネイティブ動画処理テスト通過

## 2.0.2 — タイムライン時間表示とシーク操作

- Mac Chrome 1600×1000でタイムラインを縦スクロール後も時間目盛りの上端固定を確認
- 再生ヘッドをドラッグし、0秒から76.80秒へ移動してプレビュー時刻との同期を確認
- 117.60秒の終端付近で時刻ラベルが表示領域内に収まることを確認
- JavaScript全テスト、静的ビルド、Python動画処理・Macエンジン・YouTubeテスト通過

## 2.0.1 — 手ぶれ補正・フォント・再リンク・テロップ一致

- 端末補正の複数領域動き推定、平行移動と回転の平滑化、HORIZON、自動クロップ率をユニット試験した。Mac側はHORIZONの2パス`vidstab`設定に高精度検出、42フレーム平滑化、ガウス最適化、bicubic補間が含まれることを確認した。
- Webフォント5書体、利用可能なシステムフォント、Local Font Access、OTF／TTF／WOFF／WOFF2読み込みの選択経路を追加した。読み込みフォントのメタデータは`.project`保存・再読込で保持され、実データはIndexedDBから復元する。
- 素材の再リンク候補を名前、容量、種類、尺で採点し、一致度順へ並べる試験を追加した。候補選択後も保存済み素材IDを保持する。
- テロップのプレビューと両書き出し経路を共通Canvas描画へ統一した。1080pと4Kでラスター倍率、アンカー位置、装飾寸法が正比例することを自動試験した。
- macOS Chromeの1600×1000画面で、Webフォント候補、システムTTFの読み込み、更新後のIndexedDB復元、装飾テロップのCanvas描画、再リンク候補の一致度順表示を操作した。1080pと4Kの実Canvas描画境界はほぼ正確に2倍となり、JavaScript例外は0件だった。既存翻訳がNotoの先頭を誤変換する問題も検出して修正した。
- JavaScript全試験、静的ビルド検査、Pythonのcapabilities/images/layers/multitrack/creative/youtube/program-workflow/overlay-only/prores/reliability/server/validate_formats/validate_pipelineを通過した。YouTube 4K寸法、ProRes 10-bit 4:2:2、VFR、240fps、複数映像・4音声、複数テロップの全尺デコードを含む。

実機Safari、iPhone 16 Pro、実写HDR、実写の回転揺れ・ローリングシャッター、長時間連続編集、第三者環境のフォント差は未検証です。

## 2.0.0 — UI再編・テロップ独立装飾

- ナビゲーションを`MEDIA / VIDEO / GRAPHICS / AUDIO / ASSIST`の5領域へ再編し、動画選択では`BASIC / MOTION / COLOR / LOOKS`を右設定欄内から移動できることを確認した。別の動画を選び直しても現在の動画サブメニューを保持し、TEXTから動画を選んだ場合はBASICへ移る。
- 1600×1000のmacOS Chromeで動画、テロップ、FX、音声の選択に応じた右設定欄と左上の選択表示を操作した。390×844を含めて横方向のページはみ出しはなく、JavaScript例外は0件だった。
- 2個のテロップへShift複数選択で同じ装飾を適用し、未選択テロップが変化しないことを確認した。別の2個へ黄と青の異なる装飾を順番に設定し、同時表示時に両方の色と輪郭が残ることをDOMと画面で確認した。
- テキスト属性ペーストでは本文、開始・終了、F/Tトラックを保持し、色、二重輪郭、影、背景、文字組み、位置、透明度、アニメーションだけが深いコピーで移る。自動保存後の再読込でも3テロップの状態が完全一致した。
- `npm test`、`npm run build`、Pythonのcapabilities/images/layers/multitrack/creative/youtube/program-workflow/overlay-only/prores/reliability/server/validate_formats/validate_pipelineを通過した。Mac ZIP（459,777 bytes）を生成して内容検査も通過した。

実機Safari、iPhone 16 Pro、実写HDR、長時間連続編集、第三者のMac環境は今回未検証です。

## 1.17.0 — 調整・透明度キーフレーム・オーバーレイ移動

- FX／TEXTの縦方向だけのドラッグを含むF/T1〜F/T3移動、横位置と尺の維持、終了時のレイヤー確定を自動試験した。
- 透明度キーフレームの滑らかな補間、プロジェクト保存・再読込、属性コピーの独立性を自動試験した。Mac FFmpegで赤い下段と青い上段を合成し、透明→不透明→透明の3時点を実画素で確認した。
- ガンマと黒浮かせを含むブラウザ／PythonのRGB計算一致、Mac側のLUT、シャープ、周辺光量フィルタ構成を検証した。
- 標準テロッププリセット、イタリックのプレビュー／ラスター／保存、プリセット適用後の文字組み維持を確認した。
- macOS Chrome 152・1600×1000で、動画選択時のADJUST切替、透明度点の保存、FXのF/T1→F/T3縦ドラッグ、標準テロップ4種、右クリックメニューの外側クリック解除を操作した。JavaScript例外は0件だった。
- `npm test`、`npm run build`、Pythonの全13動画処理試験、Mac ZIP生成を通過した。

iPhone 16 Pro Safari、Mac Safari、実写HDR、長時間連続編集、色調整のリファレンスモニターによる主観評価は今回未検証です。

## 1.16.0 — 英語表示・3テロップトラック・複数原音

- macOS Chrome 152で日本語／英語切替、MEDIA動画の無音ホバープレビュー、3映像・3FX・3テロップ・3音声項目を含む複雑な状態を作成し、自動保存後の更新と`.project`再読込が完全一致することを確認した。
- 1600×1000のChromeで左右の縦境界を220pxから290pxへドラッグし、FX／TEXT 3トラック、プレビュー上のテロップ本文・サイズ変更、テロップの別トラックへのドラッグ、右クリック、動画なしタイムラインの再生を確認した。JavaScript例外は0件だった。
- ブラウザ音声ミキサーとMac FFmpegで、縦に重なった3動画レイヤーの原音が同時に含まれ、各Vトラック音量が反映されることを周波数解析で確認した。AトラックのSolo時は従来どおり指定音声だけを出力する。
- Mac FFmpegで動画素材なしの黒背景＋テロップ＋FXを1.5秒のH.264/AACへ書き出し、全尺デコードと文字画素を確認した。
- `npm test`、`npm run build`、Pythonの全12既存動画処理試験、追加したoverlay-only試験、ローカルサーバー試験を通過した。

iPhone 16 Pro Safari、Mac Safari、実写HDR、長時間連続編集、第三者環境の受け入れ試験は今回未検証です。

## 1.15.2 — コピー／複製の上限処理

- 複数種類の選択を貼り付ける際、上限済みのFXを除外し、空きのあるテキストだけを元の相対時刻で追加できることを自動試験で確認した。
- テキスト300個、FX100個の上限到達後は追加結果を空として返し、存在しないIDを選択対象にしないことを確認した。
- 映像と分離音声を複製した場合、新しい映像IDと音声IDが相互に正しく連動することを確認した。
- Macエンジンへ接続したChromeで1440×1000と390×844を確認し、テロップ追加・番組インパクト適用・横方向のはみ出しなしを確認した。未指定faviconの404も解消した。
- `npm test`、`npm run build`、Pythonのcapabilities/images/layers/multitrack/prores/reliability/server/pipeline/formats/creative/youtube/program-workflow、Mac ZIP生成を通過した。

iPhone 16 Pro Safari、実写HDR、長時間連続編集、第三者のMac Safariは今回未検証です。

## 1.15.1 — TV番組テロップ

- macOS Chrome 152で「番組二段・青赤」と「番組インパクト」を実際のタイムラインへ配置し、二重アウトライン、2行の白／赤切り替え、指定語のみ黒またはサーモン色へ変わることを目視確認した。
- 同じ編集をブラウザ経路で640×360・30fps・H.264/AACへ書き出し、180/180フレーム、映像尺6.000秒、全尺再デコードを確認した。1.5秒と4.2秒のプレビュー／完成フレームを比較し、文字、行色、強調語、内外フチの一致を確認した。
- 外フチが隣接する強調語の前面へ重なる問題を実操作中に検出し、プレビューを外フチ層と文字層へ分けて修正した。修正後の実Chrome操作ではJavaScript例外0件だった。

参考画像そのものの書体は利用環境のフォントに依存するため完全一致ではありません。第三者のMac SafariとiPhone Safariでの表示差は未検証です。

## 1.15.0 — 番組フロー・書き出し一致・可変ワークスペース

- 合成H.264/AAC素材をmacOS Chrome 152へ読み込み、黒タイトル、映像フェードイン、3つの連続テロップ、終端の暗転を画面操作で作成し、ブラウザ経路でMP4を書き出した。FX 2個、テキスト4個、境界ドラッグ78px、進捗画面の表示を確認し、操作中のJavaScript例外は0件だった。
- 出力映像は640×360・30fps・H.264 High・180フレーム・映像尺6.000秒。全尺再デコードを通過し、0.5／2.9／3.9／5.9秒のプレビューと出力画像を目視比較した。黒タイトル、黄・青テロップの切り替え、終端の完全な黒を確認した。
- AACの符号化パディングを含むトラック尺は6.080秒だった。編集映像は180フレームで6.000秒に固定し、音声は編集尺より短くないこととパディングが120ms以内であることを完成検証へ追加した。
- Mac FFmpeg経路でも実動画を生成し、黒保持、フェード中の画素、テロップの色・位置・サイズ、切り替え境界、終端暗転、H.264/AAC、全尺デコードを自動試験した。テロップの左／右揃えで生じていたラスター余白分の位置差も補正した。
- Black FadeのHoldと切り替え時間はプレビューと両書き出し経路で同じ半開区間に統一し、境界フレームで前後のテロップが重ならないことを確認した。

第三者のMac環境、Mac Safari、iPhone 16 Pro Safari、長尺YouTube素材の連続編集、主観画質・音質は未検証です。

## 1.14.0 — YouTube書き出し・テロップ・メモリ管理

- 16:9の1080p／1440p／4K出力寸法と、YouTube High／MaximumのAAC 320kbps設定を自動試験へ追加。
- テロップ300個の保存上限、装飾値の検査、標準字幕／肩書きプリセットを自動試験で確認。
- Mac側は複数テロップを単一のfilter graphで合成し、映像の再圧縮を一度に限定。
- プレビュー更新頻度を24／30／60fpsから選べること、GPUテクスチャとデコーダを解放できることを確認。
- macOS Chrome 152で実写 `IMG_7697.MP4` を読み込み、3種類のテロップを時間軸上の別区間へ配置して1080pを書き出した。出力は1920×1080・30fps・H.264 High・AACステレオ約308kbpsで、90/90フレームのハッシュがすべて異なり、全尺再デコードを通過した。冒頭・中盤・終盤を画像でも確認し、映像の動き、アウトライン、影、帯背景を目視確認した。
- 同じブラウザ経路で3840×2160・30fpsの4K H.264/AACも実生成し、30/30フレームがすべて異なること、全尺再デコード、テロップ描画を確認した。短尺の機能確認であり、長時間4K編集の速度・メモリ評価ではない。
- Macの表示値では搭載メモリ32GB、検証時のJavaScriptヒープ約8.2MB／上限約4.4GBを確認。手動解放、10秒／30秒後の自動解放設定を画面から操作した。長時間のリーク評価ではない。
- 実機Safariと第三者のMac環境での長時間受け入れ試験は未実施。

## 1.13.2 — 端末書き出しの動画フレーム修正

- 書き出し用の可変Canvasを毎フレームGPUへ再転送することを単体試験する。
- iPhone 16 ProのHEVC/SDR/VFR実写 `IMG_7697.MP4` から、ブラウザ経路で3秒と別区間2秒の1080×1920・30fps H.264/AAC MP4を2回書き出した。
- 1回目は90/90フレーム・90種類、2回目は60/60フレーム・60種類のフレームハッシュを確認した。両方を再デコードし、各区間の冒頭・中盤・終盤を目視して、被写体と画角が連続して変化していることを確認した。
- iPhone 16 Pro Safari実機での最終受け入れ確認は別途必要。

## 1.13.1 — ページズーム抑止・ネイティブ操作化

- タイムライン外の`gesturestart/change/end`、複数タッチ、`Ctrl/⌘ + wheel`を抑止する。
- 同じ入力がタイムライン内では既存の時間軸ズームへ渡ることを単体試験する。
- `⌘/Ctrl +`、`-`、`0`によるブラウザ拡大を抑止し、編集ショートカットと入力欄は維持する。
- Chromeの実操作ではページ拡大率が変わらず、タイムライン上だけ拡大率が変わることを確認する。iPhone 16 Pro Safari実機は未検証。

## 1.13.0 — 範囲選択・レイヤー横断移動・等間隔ガイド

- タイムラインの矩形範囲と各素材矩形の交差判定、逆方向ドラッグ、映像／音声をまたぐ選択を自動試験した。
- 選択済み素材からドラッグを開始しても集合を維持するよう、選択と移動開始の順序を修正した。
- 映像・音声・FX・テキストの一括移動は元の時間差を保持し、0秒より前へ移動しない。
- ドラッグ中は選択矩形と色付き等間隔ガイドを表示し、ポインター終了・中止時に確実に消去する。
- ポインター移動ごとの全DOM再探索を廃止し、ジェスチャー開始時に作る要素索引を再利用する。
- Chrome実操作では8項目をレイヤー横断で選択し、全項目が同じ0.233秒だけ移動すること、左右20%の等間隔ガイド表示、実行時エラーなしを確認した。

## 1.12.0 — 書き出し静止化修正・トラック操作・解析カラー

- 端末内書き出しで連続デコード用Canvasが再利用され、同一画像が保持され得る経路を廃止した。出力フレームごとにVFR対応のソース時刻を指定して取得する。時刻が同一のFreeze／Holdだけを再利用するユニット試験を追加した。
- ChromeのWebCodecsで内蔵の動く素材から1秒・30fps、90,533 bytesのH.264/AAC MP4を実生成した。完成ファイルは30フレーム、1.0秒で、0.08／0.48／0.88秒の縮小画面に平均0.46〜0.78階調の差があり、静止画の連続ではないことを確認した。これはiPhone Safariの実機結果ではない。
- タイムライン左側のV1〜V3表示、A1〜A4ミュート／0〜200%音量を追加した。Mac FFmpeg側は上段を非表示にした実MP4で下段の画素へ戻ることを確認した。
- 動画、音声、FX、テキストの複数選択ドラッグを追加し、相対間隔、テキスト尺、Undo単位をユニット試験した。
- UNDERプリセットと、解析結果の平均輝度・10/90パーセンタイル明暗幅・クリップ率を使うCINEMA UNDERを追加した。自動確定は行わず、明示操作時だけ適用する。
- Chrome 1440×960で3映像・4音声の左端操作、50%音量、表示切替、レイアウト、JavaScript例外0件を確認した。
- `.qa-media/real/IMG_7917.mov`の冒頭1秒へUNDER相当の色調整を適用し、540×960・30fpsのH.264/AAC処理プレビューを生成した。0.1秒と0.8秒の平均画素差は36.982で、全尺デコードと元ファイルSHA-256不変を確認した。素材はHEVC/SDR、1080×1920、約58.68fpsで、VFR判定は1.9.0時点の全尺プロキシ検証結果を継続参照する。
- `npm test`、`npm run build`、Pythonのcapabilities/images/layers/multitrack/creative/prores/reliability/server/validate_formats/validate_pipelineを通過した。ローカルFFmpegにない任意機能は事前判定の対象とした。

iPhone 16 Pro Safari、Mac Safari、実写HDR、実写手ぶれ補正、長時間連続編集、主観画質・音質は今回未検証です。

## 1.11.0 — 安定基準・プレビュー・モーション操作

- `v1.10.0`を安定基準としてタグ化し、1.11.0で追加変更を分離した。
- 再生中のシーケンス行をキャッシュし、毎フレームのタイムラインキー生成を省いた。既存の100,000回プレビュー位置検索はNode環境で4.27msだった。これは実機FPSの測定値ではない。
- 動画・静止画のPush in／Pull out／上下左右Panをブラウザプレビュー、端末書き出し、Mac FFmpegへ実装した。パターン静止画の先頭・末尾フレーム差と、H.264/AAC全尺デコードを確認した。
- Option／Altドラッグ中の複製元表示、色付き等間隔バー、FX／テキスト両端トリム、テキストのプレビュー直接移動と中央吸着、文字間隔・行間隔、数値直接入力を追加した。
- Chrome 1440×1000の自動操作で上記操作、動画3個配置、再生を確認し、JavaScript例外は0件だった。
- `npm test`、`npm run build`、Pythonのcapabilities/images/layers/multitrack/creative/prores/reliability/validate_formats/validate_pipelineを通過した。ProResは10bit 4:2:2とPCM、グラデーション256階調超、全尺デコードを確認した。

iPhone 16 Pro Safari、Mac Safari、実写HDR、実写手ぶれ補正、長時間連続編集、主観画質・音質は今回未検証です。

## 1.10.0 — 共通タイムライン操作と直接配置

- ブラウザ版のMEDIAカードを常時ドラッグ可能にし、V1〜V3とA1〜A4への任意位置配置を実装した。読み込み時の自動配置は行わない。
- Shift複数選択、映像・音声・FX・テキスト共通のコピー／切り取り／貼り付け／複製／削除、Optionドラッグ複製を実装した。映像に連動する音声は重複コピーしない。
- CUTに不透明度と透明フェードを追加し、プレビュー上の位置ドラッグ、中央吸着ガイド、タイムライン上の等間隔候補表示を実装した。
- タイムライン領域のCtrl/Command付きwheelとSafari gestureイベントを捕捉し、ページ拡大ではなくタイムラインの1〜10倍ズームに割り当てた。
- テキストのフォント名を安全化して保持し、検出候補と任意色入力を表示した。輪郭は旧プロジェクトを含めて0へ正規化し、DOM／Canvas／書き出しラスターのstroke描画を削除した。
- Chrome 1440×1000の自動操作で、16個のフォント候補、色入力、輪郭操作なし、映像・FX・テキストの複数選択、同時コピー／貼り付け、タイムラインズーム、プレビュー位置変更、素材のドラッグ配置と使用中素材削除を確認した。JavaScript例外は0件だった。
- ユニット試験に中央吸着・サイズ上限、等間隔候補、wheelズーム、輪郭無効化を追加した。

Safari実機のピンチ、Optionドラッグ、フォント表示差、iPhone 16 Pro、長時間編集は未検証です。

## 1.9.1 — FXドラッグ配置・磁気吸着

- FXパレットからFXトラックへのドラッグ配置、配置済みFXとテキストの横移動を実装した。
- 再生ヘッド、映像・音声の編集点、FX・テキスト両端を共通の吸着候補とし、表示倍率に依存しない8画素の判定範囲を使用する。Altによる一時解除、30fpsフレーム丸め、末尾制限、テキスト尺の保持をユニット試験で確認した。
- 素材ドロップと映像クリップ移動にも再生ヘッド吸着を追加し、吸着位置を縦ガイドで表示する。
- Chrome 1440×1000でCamera FlashをFXパレットから5.00秒の再生ヘッドへドロップし、6.43秒へのドラッグ移動、吸着ガイド、Undoによる5.00秒復帰を確認した。操作中のJavaScript例外はなかった。

Mac SafariのHTML5ドラッグ、トラックパッドでの実操作、iPhoneのタッチ移動は未検証です。

## 1.9.0 — エンジン強化・配置動線・連動音声

- `npm test`：PASS。既存試験に加え、分離音声の既定連動、解除・再連動、映像との同時分割、削除、保存復元を検証した。
- `npm run build`：PASS。静的参照、全JavaScript構文、ワークフロー構造、重複IDを検証した。
- Python動画処理テスト：PASS。H.264/AAC、VFR、120fps、240fps入力、速度0.05〜20倍、速度ランプ、4音声トラック、静止画、3映像レイヤー、テキスト、カラー、キャンセル、生成物再検証を通過した。
- ProRes実生成：ProRes 422 / `yuv422p10le` / PCM音声のMOVを生成し、ffprobeと全尺デコードを通過した。通常SDRグラデーションへ小数カラー調整を適用し、高精度内部処理を通した。
- 高品質スロー実生成：FFmpeg `minterpolate` の動き補償設定で0.25倍の出力を生成し、H.264/AAC、尺、全尺デコードを確認した。
- 実写UI通し検証：`IMG_7917.mov`（HEVC/SDR/VFR）とPNGをChrome上のMacエンジンへ読み込み、読み込み直後0クリップ、MEDIAの縦スクロール、ドラッグ配置、右クリック分割、V1〜V3、連動音声、速度ランプ、高品質スロー、Crop、カラー、透明度、映像フェード、Flash、Black Fade、日本語テキスト2層、540p処理プレビューを確認した。6.004秒の処理プレビューは48.3秒で生成し、短い再生3回のJavaScriptヒープ範囲は約1.48MBだった。この短時間測定だけでメモリリークがないとは判断しない。
- ローカルHTTPサーバー試験：認証、Origin制限、Range配信、プロジェクト往復、アップロード、非同期プロキシ、診断ログを確認した。

現在のローカルFFmpegには`vidstab`が含まれていないため、新しい高精度手ぶれ補正設定の実写出力は未検証です。`ffmpeg-full`等の`vidstab`対応ビルドで別途確認が必要です。iPhone 16 Pro Safari、Mac Safari、実写HDR、長時間連続編集も未検証です。

## 1.8.0 — テキスト描画・高度編集・プレビュー応答

- TEXTを最大20レイヤーへ拡張し、文字ごとの選択・複製・削除、タイムライン表示、複数行、日本語、書体、太さ、色、背景、輪郭、整列、位置、不透明度、開始・終了、Fade in/out、Rise／Slideを実装した。
- ブラウザ／iPhone書き出しは共通Canvas描画を使う。Mac版はブラウザが生成した透過PNGをFFmpegのoverlayで合成し、drawtextのないローカルFFmpegでも日本語を出力できることを確認した。PNGは8MB上限・署名・Base64を検査し、.projectと自動保存には保持しない。
- プレビューは文字DOMを再利用し、FX内容が変わらないフレームのDOM更新、停止中の同一動画フレームと静止画のWebGL texture uploadを省いた。80回のフレーム移動後も同じ文字DOMが保持された。
- テキスト正規化・永続データからの一時PNG除外、Canvas共通描画、MacのPNG合成、Mac機能判定を自動試験へ追加した。

高度編集シナリオはApple M2 Max MacBook Pro（12コア、32GB）、macOS 26.5、Chrome 152で実施した。`IMG_7917.mov`（23.177秒、1080×1920、HEVC/SDR、約58.68fps VFR、AAC）と1200×1600 PNGを画面から読み込み、指定位置の右クリック分割、V1〜V3、音声分離、0.65→1.8倍Ease In/Out、Crop、カラー、透明度、映像フェード、Flash、Black Fade、2つの日本語テキストを同時に設定した。

結果：6秒シーケンスの540×960・約30fps処理プレビューを41.775秒で生成した。出力は6.004秒、1,610,724 bytes、H.264/AACで、全尺デコードを通過した。抽出フレームでも2つの日本語文字、背景、色、映像レイヤー合成を目視確認した。3回×約0.9秒の短い再生でJavaScriptヒープは5.78→6.93MB（測定範囲差1.15MB）だった。短時間かつChromeの概算値であり、長時間リーク評価ではない。画面操作中にJavaScript例外はなく、保存済みプロジェクト再読込時の欠落リソースもなかった。

今回確認していないもの：iPhone 16 Pro Safari、SafariのHEVC/HDR/VFRデコード、実写HDR、4K出力、60/120/240fps実写の高度編集、数十分の連続再生・シーク、音声の主観品質、実写手ぶれ補正のCrop量と破綻。これらを検証済みとは扱わない。

## 1.7.3 — ワークフローUI

- 上部ナビゲーションを「素材準備・編集・仕上げ・補助」の4工程に分け、各機能の既存IDと切り替え処理を維持した。
- タイムライン操作を「履歴・クリップ・範囲・編集」の4群に再配置した。デスクトップでは全操作を表示し、800px以下では従来どおりコピー等を「その他」に収める。
- 暗色、余白、境界、選択状態、スクロールバーを統一し、`prefers-reduced-motion`にも対応した。
- `.qa-media/real/IMG_7917.mov` は23.177秒、縦1080×1920、HEVC/SDR、約58.68fpsのVFR、AAC音声として認識した。全尺の720p/30fps H.264プロキシ、サムネイル8枚、波形を生成し、冒頭3秒を1080×1920 H.264/AACへ書き出して全尺デコード検証を通過した。追加のApple Spatial Audioストリームは今回の書き出し対象に含めていない。

Chromeの1440×1000と402×874相当で、レイアウト、工程切り替え、主要ボタンの表示、ビューアーとタイムラインの非重複、JavaScriptエラーがないことを確認した。iPhone 16 Pro SafariとM2 MacBook Proでの実機表示は未検証。

## 1.7.2 — 指定時刻の分割・右クリック

- クリップ内のクリック位置をタイムライン時刻へ変換し、再生ヘッド位置で映像または音声を分割する。端点、GAP、Freezeは分割不可としてメニュー上でも無効にする。
- Mac向け右クリックメニューに、分割、設定表示、コピー、切り取り、複製、属性ペースト、通常削除、前詰め削除を追加した。画面端での位置補正と分割可否をユニット試験で確認した。
- `dist/` はGitHub Pagesの静的公開ディレクトリとして維持し、素材・編集データ・書き出しは同梱しない。`.qa-media/` はGit管理対象外の実写検証専用とする。

1280×820のChrome自動操作で、右クリック位置3.00秒の映像を0–3秒／3–12秒へ、6.00秒の分離音声を0–6秒／6–12秒へ分割した。右端付近のメニューが画面内に収まり、JavaScriptエラーがないことも確認した。

未検証：macOS Safari実機の右クリック／Controlクリック、Magic Mouse・トラックパッド、`IMG_7917.mov` をブラウザ画面から操作する実写分割と端末書き出し。

## 1.7.1 — モバイル作業面・保存管理・機能判定

- 402×874相当で確認された、ビューアーがタイムラインのツールバーとトラックを覆うCSS競合を修正。旧モバイル配置を削除し、ビューアー・タイムライン・素材または設定の3段構成へ統一した。
- タイムラインのピンチ拡大は、距離から1〜10倍へ制限する計算と、ピンチ中央の時刻を維持するスクロール位置をユニット試験に追加した。Safari実機の2本指操作は未検証。
- 端末診断の出力を表示後に削除し、通常書き出しは新しい成功ファイルを記録できた場合だけ前回ファイルを削除する。保存容量画面から保持素材、書き出し数、概算容量を確認できる。IndexedDB／OPFSの実機長時間試験は未実施。
- Mac側はlibx264、vidstab、zscale/tonemap、drawtextを個別表示し、選択編集に必要な機能がない場合はFFmpeg処理開始前に停止する。`tests/capabilities.test.py`で各不足条件を検証した。
- 書き出しプリセットはプロジェクト本体のアスペクト比を変更せず、処理用スナップショットにだけ適用する。編集比率を使う選択肢と、明示した比率の選択肢も追加した。
- GitHub ActionsへPython側の画像、3映像、4音声、耐障害、ローカルサーバー、形式、処理パイプライン試験を追加した。実行環境のFFmpegに任意フィルターがない場合は、その機能を実行済みとはせず、事前停止を検証する。

短い内蔵合成素材による端末書き出しはCodex内ブラウザで成功済み。iPhone 16 Pro Safari、実写HEVC／HDR／VFR、M2 MacBook Proの4K・60/120/240fps、長時間メモリ、画質・音質・速度、実写手ぶれ補正比較は引き続き未検証。

検証環境：Linux x86_64、FFmpeg 6.1系、Python 3.12、Node.js。合成映像に加え、ユーザー提供のH.264/SDR実写素材を使用しました。クラウドChromeで一部UI操作も確認しました。Apple Siliconでの速度測定・実写HDRの色評価・SNS実投稿は未実施です。

## 処理パイプライン

| 試験 | 結果 |
|---|---|
| 4K・60fps・10bit HEVC/HLG生成 → SDRプロキシ | PASS |
| HLG HEVC 4K → 1080p60 H.264 Rec.709 | PASS |
| VFRの検出 → CFR出力 | PASS |
| 120fps音声なし → H.264/AAC | PASS |
| 240fps入力 → 60fps出力 | PASS |
| Trim / 9:16 Crop / 音量・Fade | PASS |
| 0.05倍・20倍 | PASS |
| Ease In/Out 0.1→8倍 + 原音同期 | PASS |
| Frame blending + color + text + hold | PASS |
| vidstab検出・補正2パス | PASS |
| 複数クリップ + 黒の空白 + BGM | PASS |
| Best Moment・Intent別の特徴量解析 | PASS |
| キャンセル | PASS |
| 元素材ハッシュ不変 | PASS |

出力はffprobeでコーデック・映像寸法・映像と音声の長さを確認しています。AACパケットとフレーム境界の丸めによる差を認め、映像/音声の長さ差と期待尺の差は150ms以内を合格条件にしました。ケース別の実測値は `validation/pipeline.json` を参照してください。

解析の全カテゴリはアルゴリズムを実装していますが、実写の検出品質を評価した結果ではありません。表情・ポーズ・視線の意味認識や専門家による候補の採点は含みません。

## 状態・API

- JavaScriptの構文検証：PASS。
- 時間マッピングの相互変換、0.05〜20倍、4種のランプ、空白、プロジェクトJSON：PASS。
- ローカルAPI：未認証拒否、別Origin拒否、メディアのRange配信、ディスク保存/復元、ストリーム読み込み、非同期プロキシジョブ：PASS。
- クラウドChrome：合成素材のImport、WebGL画面表示、再生/停止、フレーム送り、分割、0.05倍→1倍Ease In/Out設定、9:16、COLDルック、Undo/Redo、自動保存後の復帰、再リンク、Best Momentスキャン候補表示を確認。
- `.project` のダウンロード完了イベントは取得できず、実機でのファイル保存・再読込は未検証。UIからの開始と自動保存は動作。
- Safari、ブラウザHEVCデコード、音声試聴、滑らかさの定量評価は未実施。

## メモリ

4K60 HEVC/HLG → 720p30 SDRプロキシ相当のFFmpeg処理、入力とフィルタ・エンコーダのスレッド数を2に制限して測定。

| 入力尺 | 子プロセスの最大RSS |
|---|---:|
| 0.6秒 | 377.5 MiB |
| 6秒 | 379.6 MiB |

短尺で、動画の長さに比例したフレーム蓄積が生じないことを確認しました。長時間稼働・全機能・実機でのリークがないことを保証する測定ではありません。詳細は `validation/memory.json`。

## 採用構成と理由

- HTML/CSS/ES modules：依存パッケージなしで配布し、同じ画面をブラウザとMacで使用。
- HTMLVideoElement＋WebGL：低負荷の近似試写。4KはMacでプロキシ化。
- ネイティブFFmpeg：HEVC、HDR、VFR、vidstab、H.264/AACを同じパイプラインで処理。
- Web Worker：ブラウザのフレーム特徴量計算。毎フレームの画素バッファは処理後に解放。
- Python標準ライブラリ：ローカルHTTPとジョブ制御。127.0.0.1にのみバインドし、起動トークンで認証。
- CPU libx264：この環境で検証できるエンコーダを採用。VideoToolboxは能力の検出のみ。
- FFmpeg.wasm：大きな素材の複製・メモリ圧迫・スタビライズ構成の制約を避けるため、この版では不採用。
- WebCodecs：コーデック対応がブラウザ実装に依存し、HEVC/HDRを必須とするV1の主エンジンには不採用。

## V1受け入れ前に必要な実素材試験

1. iPhoneのSDR 4K60、Dolby Vision/HLG、1080p120/240、縦動画、長尺VFRを各1本。
2. ShingoさんのApple Silicon Macで起動し、ブラウザの動画再生とプロキシ生成を確認。
3. 肌・白い衣服・照明ハイライトを含む映像で、HDR→SDRとカラーの色を評価。
4. 激しいパン・歩き撮り・髪や服の動きで、スタビライズと候補検出を評価。
5. ランプ境界の音、数十分の連続編集、キャンセルと再試行、終了後の再開を確認。
6. Instagramへ実投稿し、画角・再生・色・音声を確認。

未検証項目を合格扱いにはしていません。詳しい操作上の制約は README.md を参照してください。

## 1.1.0 信頼性改善

- MP4/WAVは一時ファイルへ生成し、映像/音声の有無・長さ・コンテナの検証後に確定。
- 不完全な生成物に限り1回再生成。元ファイルや設定のエラーは再試行しない。
- 最終出力はFFmpegで全尺のデコード検証を実施。
- 診断ログを保存し、認証済みAPIからのみ取得可能。
- ブラウザの素材/BGM読み込みと解析シークにタイムアウト・キャンセル・後処理を追加。
- 短いタイムラインは小数秒の目盛りで表示。再リンク待ちに以前の映像を残さない。

`tests/reliability.test.py` の6試験（1回復旧、上限2回と完成済みファイル保護、入力エラー非再試行、キャンセル、音声先頭ストリームの全尺検証、破損プロキシ再生成）全件PASS。`tests/media-state.test.mjs` は成功・即時イベント・キャンセル・タイムアウト・読み込みエラーを検証。更新パイプラインと認証付き診断APIもPASS。

## 実写素材

入力：512×910、H.264 High、8bit SDR Rec.709、30fps CFR、AAC、18.633秒。4K/HEVC/HDR素材ではありません。

- 全尺の1080×1920 H.264/AAC出力、0.05倍・20倍・ランプ混在出力を検証。アップスケールは元映像の細部を増やしません。
- 4〜10秒区間をNATURAL補正、1080×1920で書き出し。1.1.0で2回成功、全尺デコード検証済み。33.16秒/41.65秒（Linuxでの参考値、Mac性能を表しません）。
- 初回の旧処理で中間MP4の `moov atom not found` を1回観測。原因は未特定。同条件の旧処理再試行2回と更新版2回は成功。自動再生成が元の原因を解消したとは結論しません。
- 元素材のハッシュ不変を確認。人物・髪の動きにBest/Motion候補あり。この素材では静止/低変化区間の候補なし。人物意味認識の品質試験ではありません。
- `validation/reliability-real.json` は集計のみ。実写動画本体は同梱していません。

## 1.2.0 iPhone / 端末内書き出し

追加経路：Mediabunny 1.56.0 + WebCodecs + Worker + OffscreenCanvas。H.264/AACを時刻指定で生成し、OPFSへ位置指定の小さな書き込みを行います。Fast Startはメタデータ領域の事前予約方式。全フレームと音声をメモリへ蓄積しません。処理後に映像・音声を全尺デコードし、フレーム数・コーデック・尺を検証します。

端末内に素材のBlobをIndexedDBで保存し、自動保存されたプロジェクトから再開します。元の写真ライブラリは変更しません。完成MP4は共有画面またはdownloadリンクで保存し、直近の完成出力をOPFSに保持します。共有操作が返ったことを写真への保存完了とは判定しません。

### 実施した試験

- 出力寸法（1080p/4K、9:16）、Source FPS上限60：PASS。
- 全4ランプ、0.05〜20倍、Holdを含む映像時刻計算：既存モデルとの一致PASS。
- ステレオ補間、音量、Fade、補正用の既知の平行移動推定とcrop上限：PASS。
- 本番と同じMediabunny MP4 muxer / StreamTargetでH.264/AACの実パケットを位置指定書き込み。先頭音声ストリームの合成入力、Fast Start、ffprobe尺検証とFFmpeg全尺デコード：PASS。
- 実PCM音声をストリームで読み、サンプル境界以外からの区間取得、速度ランプ混合、Hold/Mute、BGMループ境界を検証：PASS。
- JavaScript構文・静的アセット参照、従来の時間モデル・メディアイベント試験：PASS。
- アプリの「端末版の対応状況」に短尺の書き出しテストを実装。ユーザー端末でWorker・デコード・GPU・エンコード・OPFS・出力検証を実際に通せます。テストは編集プロジェクトを変更しません。

### 未検証・非同等の項目

この実装はiPhone実機で未検証です。上記のMP4試験はmuxer/IOの検証であり、iOSのWebCodecsエンコーダ・GPU処理を通した試験ではありません。iPhone Safariでのタッチ操作・写真共有保存・ファイル保存・長尺/4Kメモリ測定は未実施です。「完全対応済み」とはしません。

- HDRは検出して停止します。ブラウザの不確かな暗黙変換で色を確定しないためです。現状、正確なHLG/PQ→SDRはMac版が必要です。
- 端末内の原音速度変更はリサンプリングで、音程も変化します。BGMは通常速度。Mac版のピッチ維持とは異なります。
- 端末内スタビライズは低解像度での平行移動追跡と平滑化です。回転・パース・ローリングシャッターやvidstab同等の補正は行いません。品質は実写で未評価です。
- Frame blendingは隣接フレームの時刻補間です。光学フローではありません。
- 画面が背景に移ると書き出しを中止し、編集を保持します。バックグラウンド書き出しは保証しません。
- 端末版はWebCodecsのH.264/AAC、Worker内OffscreenCanvas/WebGL、OPFS同期アクセスに依存します。バージョン番号だけで対応済みとはせず、実際の能力を判定します。
- ブラウザ内の保存は、OSの空き容量不足やサイトデータの削除で失われる場合があります。写真/ファイルへ完成品を保存し、元素材は保持する必要があります。

参照： https://mediabunny.dev/guide/writing-media-files 、 https://mediabunny.dev/guide/media-sinks 、 https://webkit.org/blog/13862/the-user-activation-api/ 。バンドルにMITライセンスを同梱。

## 1.3.0 — 2レイヤー / 直接編集 / プレビュー負荷軽減

2026-09-09、Linux環境で確認。

- 2レイヤーの可視区間、上段優先、下段への復帰、空白、コピーの独立性、削除、同一レイヤーの前詰め、旧データの配置変換、JSON再読込を確認。
- Pointerイベントのユニットテストで左右トリム、1操作1チェックポイント、上下レイヤー移動、キャンセル時のハンドラ解除を確認。実ブラウザ／実機タッチ操作の検証ではない。
- Linear / Ease In / Ease Out / Ease In-Outのランプ分割で、元の時間積分とソース位置が保存されることを確認。
- ネイティブFFmpegで赤→青→赤の2レイヤーMP4を実生成。フレーム境界外の編集点、H.264/AAC、全尺デコード、RGBサンプル、原本SHA不変を確認。
- 端末版音声処理で、ミュートされた上段が下段原音を覆い、下段へ戻ると正しい時間の原音が復帰することを確認。端末エンコーダそのものは未検証。
- 既存のプロキシ、0.05x、20x、速度ランプ、カラー、テキスト、保持、手ぶれ補正、複数クリップとBGM、解析、120fpsのパイプライン試験が通過。
- 再生開始時に可視タイムラインをコンパイル。200クリップのテストで時刻検索100,000回が約5〜6ms（Nodeの参考値。iPhoneの再生FPSや動画デコード速度ではない）。
- 速度積分・GPU uniformをキャッシュ。再生中の描画は最大30回/秒、ドラッグ中は既存クリップDOMの位置と幅を更新。

未検証：iPhone/Safari実機、実機共有保存、長時間4Kの速度とメモリ、実ブラウザのジェスチャー。端末HDR非対応など1.2.0の制限は継続。今回、透過合成と2本の原音の同時ミックスは追加していない。

## 1.4.0 — 静止画・音声・素材管理

2026-09-09、Linux環境。

- 資産モデル試験：拡張子／MIMEによる種類判定、検索、種類フィルター、元ファイル名を保つ表示名変更、使用中素材の保護、未使用の除外、JSON復元を確認。
- 静止画の初期5秒、12秒への延長、画像プレビューの古い非同期デコードを破棄・解放する処理を確認。
- 実FFmpeg試験：PNG静止画を6秒へ延長＋H.264動画0.5秒＋WAVのBGMループをH.264/AAC MP4として書き出し。RGBサンプル、6.5秒の長さ、全尺デコード、元素材SHA不変を確認。
- 既存JSテスト一式（レイヤー・ジェスチャー・速度・端末コンテナ・端末音声）およびローカルサーバーの認証・アップロード・プロキシ・保存試験が通過。
- 音声付きファイルに埋め込まれたアルバム画像を、映像トラックと誤認しないようネイティブ解析を修正。
- 実ブラウザQA、iPhone実機、端末エンコーダでの静止画書き出しは未検証。画像デコードの破棄はモックを用いたユニット試験であり、実機性能を表すものではない。


## 1.5.0 — Creative tools

- tests/creative.test.mjs：静止の元時刻不変、尺キャッシュ更新、ランプと分割済みランプの伸縮、速度上限下限、マウス／2本指の1トランザクションとキャンセル、透明度／FX／文字の時刻を検証。
- 8ルック×4強度×3色（肌色・明部・暗部）の96組でJavaScriptとPythonのRGB計算が一致。MONOの強度150%でも無彩色を維持。
- tests/creative.test.py：赤V1／青V2を実際にH.264/AAC化。開始は赤、中間は両色、中央は青になる透明フェードを画素で検証。白フラッシュ・黒から映像・映像から黒も画素を検証。
- 動く合成素材の末尾0.999秒を2秒静止。元フレームをffprobeの実タイムスタンプから選び、離れた時刻のフレームが一致。静止＋Rise文字のMP4全尺デコードも通過。
- LUT出力の画素テストでRGB→YUV変換行列とBT.709タグの不一致を発見し修正。補正式との差を圧縮／量子化を含む許容範囲内で検証。
- 既存のJSモデル／音声／コンテナ試験、ネイティブの速度極値・ランプ・カラー・保持・文字・スタビライズ・BGM・解析・120fpsパイプラインを検証。
- ブラウザ／iPhone16 Pro／M2 MacBook Proで今回のUI・GPU・タッチ・実時間FPSは未検証。端末内合成コードの実エンコードは端末テストで確認が必要。LUT補間、コーデック、フォント、HDR/SDR色管理で完全な画素一致は保証しない。


## 1.6.0 — Three video / four audio lanes

- tests/multitrack.test.mjs：V3優先、動画原音の非破壊分離、独立移動／分割、4段とsolo/mute、音声末尾による総尺延長、分離音声の素材保持、JSON復元、旧BGMの移行を検証。
- tests/mobile-multitrack.test.mjs：実PCM音声を4本デコードし、端末ミキサーで同時合成。ループ境界を跨ぐ0.25秒窓の4周波数と、solo/mute後の周波数成分を検証。
- tests/multitrack.test.py：透過するV3/V2/V1をH.264/AACへ実際に出力し、合成画素と4音声の周波数成分を検証。soloと音声が映像より0.7秒長い黒の末尾を含む出力も全尺デコードに通過。
- 既存creative native testで透明フェード・フラッシュ・黒フェード・静止末尾・文字・色出力の回帰を検証。
- ソース静的検査で単一要素セレクタへのforEachを検出し修正。画面機能のブラウザ実行／Safari実機／実時間FPS・長尺メモリ測定は今回未実施。レイアウトは画面内パネルと各パネルのスクロール、拡大切替でアクセスを確保する構造へ変更。

## 2026-09-27 — タイムライン表示と複合制作フロー

- Chromeで縦スクロールをF/T3行の途中へ止め、固定された時間目盛りの下へ行名が半分隠れる状態を再現。スクロール終了時に最寄りのトラック境界へ揃える処理を追加し、F/T3全体が見えることを修正前後の画面で確認。
- 実写 `IMG_7697.MP4` と `IMG_7917.mov` を読み込み、3動画クリップ／2映像レイヤー／2テロップ／2FXを配置。0.8倍速、Push In、NATURAL手ぶれ補正、露出・彩度・ハイライト、原音音量を同時に適用した4.82秒の制作シナリオをChromeで再生。
- 再生は0.00秒から4.82秒まで進行。PerformanceObserverで50ms超のLong Taskは0件、requestAnimationFrame間隔の95パーセンタイルは16.8ms。ヘッドレスChromeでの短尺参考値であり、実機Safariや長尺4K性能を示す値ではない。
- `.project` 保存後に再読み込みし、素材2、動画クリップ3、テロップ2、FX2が保存前と一致。画面上でもF/T3からV1までの行名とタイムライン行が揃うことを確認。
- `npm test`、`npm run build`、`validate_pipeline.py`、`validate_formats.py`、`server.test.py`、`reliability.test.py` はすべてPASS。

## v2.2.8 — Clip Gain Envelope（2026-10-02）

- 0 → -12 → 0 dB、0 dBスナップ／Reset、Linear／Hold、5msのStepランプ、Fade In／Outを自動検証した。
- Split点の補間Gain継承、Trim後のローカル時刻、複製の独立コピー、移動、速度変更、旧Gainポイントからの移行、Undo／Redo、Delete操作を確認した。
- Chrome実画面でCanvas上のBreakpointを直接操作し、0.0 dB表示、右クリックのHold、追加・削除、Undo／Redoを確認した。
- Mac FFmpegでEnvelope付きH.264/AACを実生成し、0 dB／-12 dB／0 dBの実波形とStep境界の連続性、全尺デコードを確認した。ブラウザ端末書き出しは同じ共通Gain関数のPCM試験を通過した。
- 200クリップ×各256点を100,000回評価する負荷試験を実行し、BreakpointごとのDOMを使わずCanvas 1枚／クリップで描画する構造を確認した。
- iPhone 16 Pro Safariでのタッチ操作、実機スピーカー／ヘッドホンによるクリックノイズ聴感、長時間プロジェクトの実測は未確認。

### Envelopeの視認性・音声時刻追従（2026-10-03）

- Chromeで実WAVの波形と0／-12／0 dBのCanvasラインを目視確認。ポイント操作後もクリップの開始位置・IN・OUTが不変で、再生時のJavaScript例外は0件。
- 100音声クリップ・各256点を読み込み、20回の縦スクロール操作を51msで処理した（ヘッドレスChromeの操作測定。実機FPSや長時間性能を示さない）。
- 異なる速度ランプ間でBreakpointの元音声位置と往復変換を検証。Trim時は元の速度区間を保持する。
- Previewへ予約したGainサンプルと共通Export計算を比較。5ms Step、既存Clip Gain、8msの境界保護を共有。実スピーカーの聴感、Safariタッチ、長時間素材、Mac URLからの波形読込は未確認。

## フェード操作統一・短尺プレビュー（2026-10-03）

- 動画／静止画／テキスト／音声／BGMのフェードを共通FADE欄、0.05秒刻みと直接数値入力へ統一。透明フェードと無音フェードの説明を日英で区別。
- 下位映像・トランジション用デコーダは通常再生の小さな時間差でシークを繰り返さず、停止時・静止・極端な速度はフレーム基準で補正。保留更新によって別クリップの描画状態を上書きしないよう修正。
- Chromeで検証用カラーテスト動画の短い6カット、0.5倍速、上位映像、テキストフェード、黒へのFXを組み合わせた4.20秒プロジェクトを読み込み・再生。最後まで進行、JavaScript例外0、途中画面でテキストと重ね映像を確認。
- npm test／npm run build、Python clip-boundary.test.py／transitions.test.py PASS。動画・テキストのフェード時刻一致と通常再生／停止／シーク中の補正条件を追加検証。
- 今回のChromeシナリオは小解像度の検証用動画で、実写4K／HDR、Safari実機、聴感、長時間負荷と制作シナリオ全体の端末MP4比較は未実施。

## 読み込み通知と音量ライン表示（2026-10-03）

- 通常インポートの進行を非モーダル通知へ変更。素材の一部が読み込めた場合の保存／処理警告も、保持される通知から詳細を開く仕様へ変更。全件失敗は確認画面を維持。
- Chromeで保存容量不足を模擬し、素材1件がライブラリに残り、ダイアログは自動表示されず、詳細ボタンから警告を確認できることを検証。
- 230秒MP3・7倍タイムラインで名前とGain Canvasの位置を確認。名前を上部、波形・音量ラインを下部へ分離。選択時に0 dB表示を追加。音量ポイント設定を右側パネルの先頭へ移動。
- Chromeの実WAVで3ポイント作成、-12 dBドラッグ、再生、クリップ範囲の不変を確認。100クリップ×256点・20スクロール操作47ms、JavaScript例外0（ヘッドレス環境の参考値）。npm test／npm run build PASS。
- 実際のユーザー環境で保存が失敗した原因は未特定。容量不足テストは原因の断定ではない。Safari実機は未検証。

## v2.2.11 — ドラッグ中の端スクロール（2026-10-03）

- 上下左右端で距離に応じた自動スクロール。ドラッグ中のホイール操作、ドロップ／dragend／Escape／画面外／blurでの停止を実装。ブラウザの転送データをフレーム処理に保持せず、ガイドは独立更新。
- Chromeの実際のマウスドラッグで、音声素材を持ったまま180px高のタイムラインを先頭から372px下へスクロールし、隠れていたA2へ同じドラッグのまま配置。音声クリップ1件・正しいレイヤー・終了後のスクロール停止・JavaScript例外0を確認。
- 同じ実画面で右へ861px、上へ0px位置までスクロールし、画面外で中止した後にドラッグ状態が解除されることを確認。
- 自動テストでスクロール方向、端への距離に応じた速度、範囲外とゼロサイズで停止を検証。Safari実機のドラッグ、トラックパッドの実機ホイール操作は未実施。

### Clip Gain Envelopeの0 dB吸着強化（2026-10-03実装、v2.2.12に収録）
- 表示距離で0 dBへの吸着を判定（通常5pxで吸着、8pxを超えると解除）。Shift中は2px／4px。吸着後の微小な手ぶれで解除されにくくし、選択点が0 dBの場合は基準線を強調する。
- 点を掴んだ位置のオフセットを保持し、掴んだ瞬間のGainの飛びを抑制。
- ChromeのUI単体検証画面で実際のマウス操作を行い、吸着・維持・解除・再吸着を確認。確定0 dB、時間1秒を保持、確定処理1回。スクリーンショット `/tmp/pve-zero-snap-qa.png`。
- 高さ40／60／100pxで上下両側・Shiftの自動試験、既存npm test、npm run buildが成功。実アプリでのSafari／iPhone実機操作は未検証。再生・書き出しのGain計算経路は変更していない。
- 操作改善の静的調査：パネルリサイズと属性スライダー操作がタイムライン全体のDOM再構築を要求する。波形解析は直列キューで、削除後の解析中止・進捗通知がない。音声／映像の配置先判定はあるが、隠れた適切なトラックへの案内は弱い。これらの負荷量は未計測で、今回は改善候補として扱う。

### 操作負荷・波形準備・配置先ガイド（2026-10-03実装、v2.2.12に収録）
- 見た目・音量のスライダー入力ではTimeline全体を再生成せず、タイミング変更時の更新を保持。パネル幅・高さの変更は1フレーム単位にまとめ、Timeline幅が変わらなければ再生成を省く。
- Chromeで音量スライダー20連続入力、メディアパネル境界15段階ドラッグを実行。双方で既存Audio Clip DOMを保持し、Timeline子要素変更0件。再生FPSや長時間使用の改善量は未測定。
- Waveformはクリップ内に待機／解析％／取得不可を表示。共有解析の利用者がゼロになれば中止してデコーダを解放、再生成による瞬間的な離脱では共有ジョブを維持。成功時は4096ピークだけ保持。
- Chromeの実WAV8秒デコードで解析途中のAbortを実行し、再要求が4096ピーク・50進捗通知・100％まで成功。自動試験で共有利用者の一部Abort、全員Abort、再要求、描き直し再利用を確認。
- Drag開始時に適切なV1–V3／A1–A4／F/T1–F/T3のレイヤー見出し・枠を強調。隠れている場合は上下端へのスクロール案内を表示し、Drop／中止で解除。日本語・英語に対応。
- Chromeで音声を持ったまま372pxスクロール→A2配置、ガイド表示・解除、横862px／上方向移動／範囲外中止を確認。JS実行エラーなし。
- npm test／npm run buildが成功。Safari／iPhone実機と大量の長尺素材は未検証。

### v2.2.12 公開前検証（2026-10-06）
- npm test／npm run build、Pythonのcapabilities・images・layers・clip-boundary・transitions・multitrack・prores・reliability・server・validate_pipeline・validate_formats・creative・youtube・program-workflow・overlay-onlyが成功。
- サーバーテストはローカル通信が許可された実行環境で成功。Mac ZIPを再生成。
- Chrome実操作の確認結果は上記2026-10-03の記録を参照。Safari／iPhone実機、長時間編集の負荷改善量は未検証。

## iPhone対応別版 2.2.13（2026-10-08）
- 元の開発ディレクトリを読み取り専用の参照元として複製。既存Git・Sites識別情報は複製せず、新しいSiteを登録。ブラウザ保存、IndexedDB、OPFS出力、Mac保存ディレクトリ、起動ポートを分離。
- ChromeのiPhoneサイズ393×852と852×393で素材取り込み・配置・カラーシート・フレーム送り・分割（2クリップ）・Undo（1クリップ）・テキスト追加・全レイヤー・書き出し設定を実操作で確認。JavaScript例外0。1440×900ではdesktop判定。ページ幅393px、横はみ出しなし。操作バーとタイムラインの重なりを修正後再検証。
- npm test全件、npm run build、Python映像・音声クリップ境界、ローカルサーバーの認証・保存・Range試験が成功。
- iPhone実機、写真ライブラリ選択、実写HDR、長時間編集、実機のMP4共有は未検証。競合は公式資料で調査、実機操作未実施。
- WebKitのiPhoneサイズでも同じ編集フローを実操作で通過（JS例外0）。一時保存の警告が操作を覆う問題を修正。WebKitテスト環境では素材の永続保存に警告が出たため、実機での再読込保持は別途確認が必要。

## iPhone素材読み込み停止の修正 2.2.14（2026-10-08）
- iPhoneはメタデータ取得後、Fileを編集経路へ保持し、映像・静止画・音声をタイムラインへ自動配置。再開用IndexedDBコピー保存は背景処理へ移動。Macの読み込み・配置方式は維持。
- IndexedDB openを5秒、保存トランザクションを15秒でタイムアウト。Safari向けにFileをBlob＋ファイル名のレコードとして保存し、復元時はFileへ戻す。旧File形式も読み取り可能。
- Chromeで保存トランザクションが完了しない状態を注入し、392msで素材の自動配置と分割を完了。15秒後にも2クリップを保持、JS例外0。
- 通常Chromeで素材配置・分割・保存・ページ再読込後の2クリップ復元を確認（372ms）。WebKitでも配置と分割を確認（651ms）、JS例外0。
- iPhone実機の素材サイズ・OSバージョンに依存する挙動は未確認。画像に見える保存待ちをコード上で除去したうえ、同等の停止状態をブラウザ試験で再現。

## iPhone操作改善とプレビュー音声競合の修正 2.2.15（2026-10-08）
- 再生セッション世代で古い非同期play／RAFを棄却。音声レーンごとに保留中playを一本化し、停止後に完了したplayは再停止。停止時はディレイ出力・反復をゼロ化。素材試聴はタイムライン全体を停止。
- IN/OUT処理のtrimClip未importを修正。異なる長さのクリップ並べ替えは重複しない位置を算出。iPhoneの複製は同じ段の後続を押し出す。
- iPhone専用クリップ一覧、再生位置スライダー、分割・削除・複製・取り消し、全体表示、範囲指定／前詰め、写真の表示時間、順番と配置時刻、音量・ミュート／原音分離を追加。通常スクロール時はトリムを開始しない。
- Codexブラウザ393×852で音声入り8秒＋3秒動画を追加、3秒へ前詰め、並べ替え、複製／取り消し、分割／取り消し、原音分離、ミュート／解除、テロップ入力と配置、写真を5秒→2秒、再読込復元、端末内MP4書き出しを実操作。590×393横画面と1440×900 Mac画面で横幅超過なし。
- 出力はH.264 320×180＋AAC、動画8秒（コンテナ8.064秒）。ffprobeとFFmpeg全尺デコードで正常。
- npm test、静的ビルド、Python動画処理パイプライン、サーバー認証・Range・保存・非同期処理試験、別版Mac ZIP生成が通過。追加試験は保留playキャンセル／ディレイ停止／古いセッション、前詰め／異なる尺の並べ替え／連動音声／写真尺を検証。
- 元版161ファイルを作成時SHA-256と照合し変更0。iPhone実機Safariでの連続操作・聴感は未確認。

## iPhone画面再設計と音声クロック 2.2.16（2026-10-08）
- Edits・Canva・CapCutの公式操作ガイドを調査。フレーム単位のタイムライン、選択クリップの文脈操作、両端トリム、必要時だけ開く詳細設定を採用。競合アプリ自体の実機操作は未実施。
- 上部44pxにアプリ名・プロジェクト名・Undo/Redo・書き出し。プレビュー／タイムラインを高さ予算で配分し、標準・プレビュー優先・タイムライン優先、境界ドラッグ、横画面の左右配置を追加。比率はその他へ、クリップ一覧は別シートへ移動。使用中の映像・音声・テキスト段を表示、未使用段は全レイヤーで展開。
- iPhone再生は音声メディアのクロックへ追従。デコード待ちでは編集時計を停止し、通常再生中のドリフト補正による反復seekを廃止。初期位置合わせ、停止中スクラブ、速度変換は保持。音声／映像同期20Hz、時計表示約12.5Hz、プレビュー最大24fps・長辺960pxとして負荷を抑制。書き出し解像度・fpsは設定どおり。
- Codexブラウザ393×650で標準のトラックスクロール領域158px、タイムライン優先276px。複製、Undo/Redo、前詰めトリム（8秒→7秒）、分割（3→4クリップ）とUndo、クリップ一覧、比率シート、8秒連続再生の末尾到達、H.264/AAC端末内MP4生成（180×320・30fps）を実操作確認。393×852、590×393、1440×900で画面幅超過0、Macはdesktopへ切替。
- npm test全件、静的ビルド、Python動画処理パイプライン、サーバー認証・Range・保存・非同期処理試験が通過。新試験は画面高さ予算、バッファ待ち、単調クロック、反復seek防止、2倍速、停止中スクラブ、選択端の直接トリムを検証。
- 元版161ファイルをSHA-256照合、変更0。iPhone実機Safariの聴感、4K/HDR・長尺・多レイヤーでの連続編集は未検証。音声の実機症状の解消を保証するものではありません。


## Project reset/load and exact frame windows (2.2.64, local)

- Invalid parseable projects (unsupported version or missing media records) are rejected by the real `loadProject` function before playback pause, URL revocation, file clearing or history replacement. New `project-load-guard.test.mjs` is included in npm test.
- Native `frame-window.test.py` exports fractional edits and speed changes with FX at 24/30/60 fps; exact frame counts/durations, audio continuity and complete decoding pass. Added to the native CI checks.
- Quantized video segments retain exact frames with bounded trimming and terminal-frame padding. Float noise below 1e-8 seconds does not create a synthetic gap; trim timestamps use fixed decimal syntax. FX compositing resets its video input timestamp origin. Final frames are normalized only when needed; exact existing videos retain stream-copy. Audio mixer/engine unchanged.
- Independent 20-second complex fixture:17 media/69 video clips/41 FX/10 captions/5 audio clips covering all4 audio lanes. Actual save/reset/load/link functions executed100 times in Node VM with UI/decoder adapters; complete JSON/engine ID references preserved. Browser-mode media restoration used a simulated persistent file store, not Safari IndexedDB.
- Real native before/restored exports succeeded at30fps(600frames) and60fps(1200frames), both20 seconds. After final changes the restored project was exported again at both rates and fully decoded. Text rasters reused the existing browser-generated rasters for unchanged captions. Test output sizes:30fps540x960 and60fps270x480.
- Final60fps decoded audio matches the pre-fix baseline sample-for-sample. Existing clip boundaries, four-track mix, transitions, region zoom, creative effects, material FX, ProRes and still-image native tests pass; npm test/build and diff checks pass.
- Physical Mac UI/playback/speaker tests could not run while the Mac was locked. Real Safari/iPhone and packaged Mac build remain unverified/unupdated. No publication. AAC near-silent decoded tail observation remains an investigation item, not claimed fixed.
- Detailed fixtures/logs: workspace `pve-vibe/lifecycle-audit/`.

## 実素材による速度・バンプ・手ぶれ補正の監査（2026-10-20／2.2.79）

- 実写 `IMG_7917.mov` / `IMG_7697.MP4`（SDR・縦位置HEVC）を使用。人物の動きとカメラの構図変更を含みます。元素材は変更せず、書き出し試験でSHA-256の維持を確認しました。
- 実アプリの読み込み→V1配置→速度変更→プレビューで、2倍速のソース時刻がタイムライン時刻の2倍になること、5.118倍速の近似プレビューが終端で停止することを確認しました。4倍を超える高速域の近似表示／原音ミュートは既存仕様です。
- 実Macエンジンで0.25／1／2／5.118倍速とease-in-out（0.5→3倍）をH.264/AAC出力。尺・全デコード・各3地点の元映像との時間対応を確認しました。出力180×320／30fpsの処理試験で、画質評価とは区別します。
- 本番のブラウザワーカーを実素材2本の4〜8秒で実行し、手ぶれ補正72点／素材、バンプ33サンプル／素材の解析を確認。バンプは3箇所／2箇所のアクセントを検出しました。実解析のバンプを書き出した音声は、FXなしの音声とデコード全サンプルが一致しました。
- 手ぶれ補正＋2倍速のMac書き出しでも、解析→ProRes中間→速度変換→H.264/AACの実処理と全デコードが通過しました。検証用vidstab対応FFmpegを一時フォルダ内だけに用意し、通常のFFmpegは置換していません。
- 元解像度でのvidstab解析・変換を全9設定×実素材2本で比較し、その後360×640に縮小して保存。OFF込み20本が各120フレーム／30fpsでデコードでき、全面黒フレームはありませんでした。強い旧設定では構図の切り取りが増え、意図したカメラ移動も抑える傾向がありました。静止画の比較も保存しました。
- 実写フレームのWebGLプレビューとCanvas書き出し変換を縦・横のサイズ、回転0／±0.04radで比較。正方形UVをそのまま回転していた不一致を修正し、RGB平均絶対誤差は回転時5.88〜6.62から0.0044〜0.0049（0〜255）へ低下。回転なしの誤差は維持しました。
- 手ぶれ補正は新規選択をOFF／WEAK／MEDIUM／STRONGへ整理。旧HANDHELD／NATURAL／GIMBAL／HORIZON／TRIPOD／AGGRESSIVEは保存互換専用です。設定名ほど別々の補正アルゴリズムではなく、水平検出・被写体分離・ローリングシャッター補正はありません。旧プロジェクトの値を読み込み時に変更しない試験を追加しました。
- プレビューとブラウザ書き出しの重複した解析ループを共通化。元時間の保持、従来計算との一致、キャンセル時のイテレーター解放、空デコードの失敗、旧設定の非再露出を試験。解析完了後にも進捗98%等が残る表示を修正し、実アプリで完了表示を確認しました。
- 393×852のiPhone幅でも補正選択肢の収まり（横方向のはみ出しなし）と、MEDIUM補正＋0.25倍速の再生進行を確認。実機iPhoneではなくブラウザの表示幅による確認です。
- `npm test`（85試験スクリプト）／`npm run build`／`git diff --check`が通過。現行設計は `docs/current-architecture.md` に整理し、旧コードの再導入を避ける参照先をAGENTS／READMEへ追加しました。
- 証拠は作業ルート `.codex-context/audit-evidence/motion-real-2026-10-20/`。人物ポージング中心の素材であり、歩行・大きな手ぶれ・HDR・実機iPhone／Safari本体の評価は未実施です。Mac用vidstabとブラウザ補正は異なる処理のため、両者の補正結果が同一になるとは評価していません。
